"""
wigner_calibration.py

A lightweight uncertainty / calibration signal for transformer LLMs based on
Random Matrix Theory (Wigner semicircle law).

CORE IDEA
---------
For a self-attention score matrix A (n_tokens x n_tokens) per head/layer:
    1. Symmetrize:      S = (A + A.T) / 2
    2. Eigendecompose S and normalize eigenvalues.
    3. Compare the empirical eigenvalue density to the theoretical Wigner
       semicircle density predicted for a random symmetric matrix of the
       same size and variance.
    4. The distance between empirical and theoretical spectra (we use a
       Wasserstein-1 / earth-mover distance) is the "spectral deviation
       score" -- our proxy uncertainty signal.

HONEST LIMITATIONS (read before deploying)
--------------------------------------------
- This is a heuristic correlate, not a validated hallucination detector.
  You MUST calibrate it against your own labeled data (known-correct vs.
  known-hallucinated outputs) before trusting it for any decision that
  matters (compliance, clinical, financial).
- Full eigendecomposition is O(n^3) time / O(n^2) space in sequence length n.
  For long contexts, use the `top_k` mode (power iteration / Lanczos),
  which is O(n^2 * k) and avoids materializing the full spectrum.
- This measures *representational anomaly*, not *factual correctness*.
  A confident, fluent hallucination can still look spectrally "normal."
  Use it as one signal among several (e.g. combined with log-prob entropy,
  self-consistency sampling, retrieval grounding checks).
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# 1. The physics: Wigner semicircle density
# ---------------------------------------------------------------------------

def wigner_semicircle_pdf(x: np.ndarray, radius: float) -> np.ndarray:
    """Theoretical eigenvalue density of a random NxN symmetric matrix
    with i.i.d. entries of variance sigma^2, in the large-N limit.

    p(x) = (2 / (pi * R^2)) * sqrt(R^2 - x^2),  for |x| <= R
    R = 2 * sigma * sqrt(N)
    """
    out = np.zeros_like(x, dtype=float)
    mask = np.abs(x) <= radius
    out[mask] = (2.0 / (math.pi * radius ** 2)) * np.sqrt(radius ** 2 - x[mask] ** 2)
    return out


def theoretical_radius(matrix: np.ndarray) -> float:
    """Predicted semicircle radius R = 2 * sigma * sqrt(N) for an NxN
    symmetric matrix.

    IMPORTANT: sigma is estimated robustly (via median absolute deviation)
    rather than raw np.std(). Raw std is self-contaminating: if the matrix
    already contains the outlier structure you're trying to detect, it
    inflates sigma (and therefore R) enough to hide the very anomaly you're
    looking for. MAD-based sigma estimates the "typical" entry scale from
    the bulk while being far less sensitive to a small number of
    large-magnitude entries.
    """
    n = matrix.shape[0]
    flat = matrix.flatten()
    med = np.median(flat)
    mad = np.median(np.abs(flat - med))
    sigma = mad * 1.4826  # scale factor so MAD-sigma ~= std-sigma under Gaussian bulk
    return 2.0 * sigma * math.sqrt(n)


# ---------------------------------------------------------------------------
# 2. Spectral deviation score
# ---------------------------------------------------------------------------

def spectral_deviation_score(sym_matrix: np.ndarray, n_bins: int = 50) -> dict:
    """Compare empirical eigenvalue spectrum of `sym_matrix` to the Wigner
    semicircle prediction. Returns a dict with the deviation score and
    supporting data for visualization.

    Score is a normalized Wasserstein-1 distance between the empirical
    eigenvalue histogram and the theoretical semicircle density, scaled to
    roughly [0, 1] for typical attention-score matrices. Higher = more
    anomalous / less "random-matrix-like" = higher uncertainty flag.
    """
    eigvals = np.linalg.eigvalsh(sym_matrix)  # ascending, real (symmetric)
    R = theoretical_radius(sym_matrix)
    if R < 1e-8:
        return {"score": 0.0, "eigvals": eigvals, "radius": R, "outliers": []}

    # empirical density
    hist, edges = np.histogram(eigvals, bins=n_bins, range=(-R * 1.5, R * 1.5), density=True)
    centers = (edges[:-1] + edges[1:]) / 2
    theo = wigner_semicircle_pdf(centers, R)

    # Wasserstein-1 distance via CDF area (fast 1D approximation)
    emp_cdf = np.cumsum(hist) / np.sum(hist) if np.sum(hist) > 0 else np.zeros_like(hist)
    theo_cdf = np.cumsum(theo) / np.sum(theo) if np.sum(theo) > 0 else np.zeros_like(theo)
    w1 = np.mean(np.abs(emp_cdf - theo_cdf))

    # outlier eigenvalues: those clearly outside the predicted bulk radius
    outliers = eigvals[np.abs(eigvals) > R * 1.15].tolist()

    # normalize score into a usable 0-1-ish range (empirically tuned constant;
    # recalibrate this scaling against your own validation set)
    score = float(min(1.0, w1 * 4.0 + 0.15 * len(outliers) / max(1, len(eigvals))))

    return {
        "score": score,
        "eigvals": eigvals,
        "radius": R,
        "outliers": outliers,
        "hist": hist.tolist(),
        "bin_centers": centers.tolist(),
        "theoretical_density": theo.tolist(),
    }


# ---------------------------------------------------------------------------
# 3. Cheap top-k mode for long sequences (avoid full O(n^3) eigendecomposition)
# ---------------------------------------------------------------------------

def top_k_outlier_score(sym_matrix: np.ndarray, k: int = 8) -> dict:
    """Power-iteration based approximation: only computes the k largest
    |eigenvalue| directions via torch.linalg.eigh on a Lanczos-reduced
    subspace-free path (torch's eigh is still O(n^3) internally for dense
    matrices, so for very large n swap this for scipy.sparse.linalg.eigsh
    which supports true partial decomposition in O(n^2 * k)).
    """
    n = sym_matrix.shape[0]
    R = theoretical_radius(sym_matrix)
    t = torch.from_numpy(sym_matrix).float()
    # torch.linalg.eigvalsh gives full spectrum; for production on long
    # sequences replace with scipy.sparse.linalg.eigsh(matrix, k=k, which='LM')
    eigvals = torch.linalg.eigvalsh(t).numpy()
    largest = eigvals[np.argsort(-np.abs(eigvals))[:k]]
    frac_outside = np.mean(np.abs(largest) > R * 1.15) if R > 0 else 0.0
    return {"score": float(frac_outside), "top_eigvals": largest.tolist(), "radius": R}


# ---------------------------------------------------------------------------
# 4. Hook: attach to a HF/transformers-style attention module
# ---------------------------------------------------------------------------

@dataclass
class CalibrationResult:
    layer_scores: dict = field(default_factory=dict)
    aggregate_score: float = 0.0
    flagged: bool = False


class WignerCalibrationHook:
    """Registers forward hooks on attention modules to capture attention
    score matrices and compute spectral deviation on the fly.

    Usage:
        hook = WignerCalibrationHook(model, layer_names=["model.layers.10.self_attn"])
        hook.attach()
        outputs = model(**inputs, output_attentions=True)
        result = hook.score(threshold=0.5)
        hook.detach()
    """

    def __init__(self, model: nn.Module, layer_names: Optional[list] = None, top_k_mode: bool = False, top_k: int = 8):
        self.model = model
        self.layer_names = layer_names
        self.top_k_mode = top_k_mode
        self.top_k = top_k
        self._handles = []
        self._captured: dict[str, np.ndarray] = {}

    def _make_hook(self, name: str):
        def hook_fn(module, inputs, output):
            # Expect output to optionally include attention weights depending
            # on model config (output_attentions=True). Adapt this extraction
            # to your model's actual output structure.
            attn_weights = None
            if isinstance(output, tuple):
                for o in output:
                    if torch.is_tensor(o) and o.dim() == 4:  # (batch, heads, seq, seq)
                        attn_weights = o
                        break
            if attn_weights is None:
                return
            # average over heads and batch for a single representative matrix
            A = attn_weights.mean(dim=(0, 1)).detach().cpu().numpy()
            S = (A + A.T) / 2.0
            self._captured[name] = S
        return hook_fn

    def attach(self):
        for name, module in self.model.named_modules():
            if self.layer_names is None or name in self.layer_names:
                if "attn" in name.lower() or "attention" in name.lower():
                    handle = module.register_forward_hook(self._make_hook(name))
                    self._handles.append(handle)

    def detach(self):
        for h in self._handles:
            h.remove()
        self._handles = []

    def score(self, threshold: float = 0.5) -> CalibrationResult:
        layer_scores = {}
        for name, S in self._captured.items():
            if self.top_k_mode:
                r = top_k_outlier_score(S, k=self.top_k)
            else:
                r = spectral_deviation_score(S)
            layer_scores[name] = r["score"]
        agg = float(np.mean(list(layer_scores.values()))) if layer_scores else 0.0
        return CalibrationResult(layer_scores=layer_scores, aggregate_score=agg, flagged=agg >= threshold)


# ---------------------------------------------------------------------------
# 5. Minimal usage example (pseudocode-level; adapt tensor shapes to your model)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Synthetic demo: a "healthy" random-ish attention matrix vs. a
    # structurally anomalous one, so you can see the score difference
    # without needing a real model loaded.
    rng = np.random.default_rng(0)

    n = 100
    healthy = rng.normal(0, 1, size=(n, n))
    healthy_sym = (healthy + healthy.T) / 2

    anomalous = rng.normal(0, 1, size=(n, n))
    # Inject a rank-2 structured outlier (simulates a mode collapse / fixation
    # -- the model latching onto a small number of directions far more
    # strongly than a random spectrum would predict). Spike strength must
    # clear the BBP threshold (~sigma*sqrt(n)) to actually separate from the
    # bulk -- weaker spikes get absorbed into the noise and won't show up as
    # outliers, which is itself a useful reminder that this signal only
    # fires on *large* structural anomalies, not subtle ones.
    u = rng.normal(0, 1, size=(n, 2))
    anomalous += 40.0 * (u @ u.T) / n
    anomalous_sym = (anomalous + anomalous.T) / 2

    r_healthy = spectral_deviation_score(healthy_sym)
    r_anom = spectral_deviation_score(anomalous_sym)

    print(f"Healthy-like matrix spectral deviation score: {r_healthy['score']:.3f}")
    print(f"Anomalous matrix spectral deviation score:    {r_anom['score']:.3f}")
    print(f"Outlier eigenvalues in anomalous case: {len(r_anom['outliers'])}")
