"""
Real three-way comparison:
1. BASELINE: plain temperature sampling from the model's own next-token distribution.
2. CLASSICAL MIXTURE (a real, simple, existing technique): linearly average the
   model's prediction from the actual context with its prediction from a separate
   "steering" context -- this is an honest, already-used approach (similar in
   spirit to prompt ensembling).
3. WIGNER/QUANTUM-STYLE COHERENT COMBINATION: treat both predictions as probability
   AMPLITUDES (sqrt(p)), coherently sum them with a phase, then square -- this is
   the actual place phase/interference can matter, since a single classical
   distribution has no interference terms at all.

Honest target: measure how often generated text contains the target word "King"
across many independent generations, for each method.
"""
import torch, re
from model import TinyGPT

torch.manual_seed(123)

ckpt = torch.load('tinygpt.pt', map_location='cpu')
stoi, itos, vocab_size = ckpt['stoi'], ckpt['itos'], ckpt['vocab_size']
def encode(s): return torch.tensor([stoi[c] for c in s if c in stoi], dtype=torch.long)
def decode(l): return ''.join(itos[i] for i in l)

model = TinyGPT(vocab_size, n_embd=64, n_head=4, n_layer=3, block_size=64)
model.load_state_dict(ckpt['model_state'])
model.eval()

BLOCK = 64
K_IDX = stoi['K']

def target_distribution(vocab_size, target_idx=K_IDX, sharpness=0.92):
    """A genuine, explicit steering target: mostly concentrated on 'K',
    small uniform floor elsewhere to keep it a valid, non-degenerate distribution."""
    p = torch.full((vocab_size,), (1-sharpness)/(vocab_size-1))
    p[target_idx] = sharpness
    return p

def next_token_probs(idx, temperature=1.0):
    idx_cond = idx[:, -BLOCK:]
    with torch.no_grad():
        logits, _ = model(idx_cond)
    logits = logits[:, -1, :] / temperature
    return torch.softmax(logits, dim=-1).squeeze(0)

def generate(method, length=150, temperature=1.0, alpha=0.15, theta=0.0):
    idx = torch.zeros((1,1), dtype=torch.long)
    idx[0,0] = stoi['\n']
    p_target = target_distribution(vocab_size)
    for _ in range(length):
        p_a = next_token_probs(idx, temperature=temperature)
        if method == 'baseline':
            probs = p_a
        elif method == 'classical_mixture':
            probs = (1-alpha)*p_a + alpha*p_target
        elif method == 'wigner_coherent':
            amp_a = torch.sqrt((1-alpha)*p_a + 1e-12)
            amp_b = torch.sqrt(alpha*p_target + 1e-12) * torch.exp(1j*torch.tensor(theta))
            combined = amp_a + amp_b
            probs = (combined.conj()*combined).real
        probs = torch.clamp(probs, min=0)
        probs = probs / probs.sum()
        idx_next = torch.multinomial(probs, num_samples=1).unsqueeze(0)
        idx = torch.cat((idx, idx_next), dim=1)
    return decode(idx[0].tolist())

def score(text, target="K"):
    return text.count(target)

N_TRIALS = 15
LENGTH = 120

print(f"Target: character '{'K'}'  |  baseline natural rate for comparison\n")

for temperature in [0.8, 1.2]:
    for alpha in [0.10, 0.25]:
        print(f"=== temperature={temperature}  alpha (steering strength)={alpha} ===")
        for method in ['baseline', 'classical_mixture', 'wigner_coherent']:
            hits = 0
            total_occurrences = 0
            for trial in range(N_TRIALS):
                torch.manual_seed(1000+trial)
                kwargs = {'temperature': temperature} if method == 'baseline' else {'temperature': temperature, 'alpha': alpha}
                text = generate(method, length=LENGTH, **kwargs)
                c = score(text)
                total_occurrences += c
                if c > 0: hits += 1
            print(f"  {method:<20} success_rate={hits}/{N_TRIALS} ({100*hits/N_TRIALS:.0f}%)  avg_occurrences={total_occurrences/N_TRIALS:.2f}")
        print()

print("\n--- sample outputs (temperature=1.0, alpha=0.2) ---")
for method in ['baseline', 'classical_mixture', 'wigner_coherent']:
    torch.manual_seed(2024)
    print(f"\n[{method}]")
    kwargs = {'temperature': 1.0} if method == 'baseline' else {'temperature': 1.0, 'alpha': 0.2}
    print(generate(method, length=100, **kwargs))

print("\n=== Does phase actually matter? theta=0 (constructive) vs theta=pi (destructive) ===")
import math
for theta_val, label in [(0.0, 'constructive (theta=0)'), (math.pi, 'destructive (theta=pi)')]:
    hits, total = 0, 0
    for trial in range(15):
        torch.manual_seed(1000+trial)
        text = generate('wigner_coherent', length=120, temperature=1.0, alpha=0.25, theta=theta_val)
        c = score(text)
        total += c
        if c > 0: hits += 1
    print(f"  {label:<28} success_rate={hits}/15  avg_occurrences={total/15:.2f}")
