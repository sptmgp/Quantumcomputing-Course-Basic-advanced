import torch, time
from model import TinyGPT

torch.manual_seed(42)

with open('/home/claude/tinyshakespeare.txt') as f:
    text = f.read()

chars = sorted(list(set(text)))
vocab_size = len(chars)
stoi = {c: i for i, c in enumerate(chars)}
itos = {i: c for i, c in enumerate(chars)}
def encode(s): return [stoi[c] for c in s]
def decode(l): return ''.join(itos[i] for i in l)

data = torch.tensor(encode(text), dtype=torch.long)
n = int(0.9*len(data))
train_data, val_data = data[:n], data[n:]

block_size = 64
batch_size = 32
device = 'cpu'

def get_batch(split):
    d = train_data if split == 'train' else val_data
    ix = torch.randint(len(d) - block_size, (batch_size,))
    x = torch.stack([d[i:i+block_size] for i in ix])
    y = torch.stack([d[i+1:i+block_size+1] for i in ix])
    return x.to(device), y.to(device)

model = TinyGPT(vocab_size, n_embd=64, n_head=4, n_layer=3, block_size=block_size).to(device)
print(f"Model params: {sum(p.numel() for p in model.parameters())/1e6:.2f}M")

optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)

t0 = time.time()
max_iters = 1200
for it in range(max_iters):
    xb, yb = get_batch('train')
    logits, loss = model(xb, yb)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()
    if it % 200 == 0 or it == max_iters-1:
        model.eval()
        with torch.no_grad():
            vx, vy = get_batch('val')
            _, vloss = model(vx, vy)
        model.train()
        print(f"iter {it}: train loss {loss.item():.4f}, val loss {vloss.item():.4f}, elapsed {time.time()-t0:.1f}s")

torch.save({'model_state': model.state_dict(), 'vocab_size': vocab_size, 'stoi': stoi, 'itos': itos}, 'tinygpt.pt')
print("saved tinygpt.pt")

# quick sanity generation
model.eval()
context = torch.zeros((1,1), dtype=torch.long)
context[0,0] = stoi['\n']
def generate(model, idx, max_new_tokens, block_size):
    for _ in range(max_new_tokens):
        idx_cond = idx[:, -block_size:]
        logits, _ = model(idx_cond)
        logits = logits[:, -1, :]
        probs = torch.softmax(logits, dim=-1)
        idx_next = torch.multinomial(probs, num_samples=1)
        idx = torch.cat((idx, idx_next), dim=1)
    return idx

out = generate(model, context, 200, block_size)
print("\n--- sample generation ---")
print(decode(out[0].tolist()))
