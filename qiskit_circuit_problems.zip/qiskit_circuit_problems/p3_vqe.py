"""
Problem 3: VQE hybrid quantum-classical loop for a toy 2-qubit Hamiltonian.
Demonstrates the actual variational principle claim from the problem: the
measured energy at every step is provably >= the true ground-state energy,
verified here against exact diagonalization.
"""
import numpy as np
from qiskit.quantum_info import SparsePauliOp
from qiskit.circuit.library import n_local
from qiskit.primitives import StatevectorEstimator
from qiskit_algorithms import VQE
from qiskit_algorithms.optimizers import COBYLA

# A toy 2-qubit Hamiltonian (stand-in for a small molecule's electronic Hamiltonian)
hamiltonian = SparsePauliOp.from_list([
    ("II", -1.0),
    ("ZZ", 0.5),
    ("XX", 0.3),
    ("ZI", 0.2),
    ("IZ", -0.2),
])

exact_energy = np.min(np.linalg.eigvalsh(hamiltonian.to_matrix()))
print(f"Exact ground-state energy (numpy diagonalization): {exact_energy:.6f}")

ansatz = n_local(2, rotation_blocks="ry", entanglement_blocks="cz", reps=2)
estimator = StatevectorEstimator()
optimizer = COBYLA(maxiter=200)

history = []
def callback(eval_count, params, value, meta):
    history.append(value)

vqe = VQE(estimator, ansatz, optimizer, callback=callback)
result = vqe.compute_minimum_eigenvalue(hamiltonian)

print(f"VQE final energy:                                    {result.eigenvalue.real:.6f}")
print(f"Number of energy evaluations logged:                 {len(history)}")
print(f"Lowest energy seen during optimization:              {min(history):.6f}")

# variational principle check: every measured energy must be >= exact ground state
violation = min(history) < exact_energy - 1e-6
print(f"\nAny measured energy below the true ground state? {violation}")
assert not violation, "Variational principle violated -- something is wrong"
assert abs(result.eigenvalue.real - exact_energy) < 0.05, "VQE did not converge close to the true ground state"
print("PASS: VQE converged close to the exact ground state, and never violated the variational bound.")
