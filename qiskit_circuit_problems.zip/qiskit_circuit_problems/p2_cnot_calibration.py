"""
Problem 2: Calibrating a 2-qubit entangling gate (proxy for cross-resonance CNOT).
Demonstrates the 2D optimization landscape from the problem: two coupled
parameters (an RZZ interaction angle and a local phase correction) must be
tuned together to match a target CNOT unitary -- unlike Problem 1's single
parameter. Uses process fidelity against the ideal CNOT as the objective.
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator, process_fidelity
from qiskit.circuit.library import CXGate

TARGET = Operator(CXGate())

def build_gate(theta, phi):
    """A parameterized 2-qubit gate: RZZ(theta) entangler with a shared local
    phase correction phi on both qubits, sandwiched by the fixed Hadamards
    that convert a controlled-Z-like interaction into a CNOT. theta and phi
    are the two parameters that must be jointly calibrated -- exactly like
    tuning amplitude AND phase together for a real cross-resonance gate."""
    qc = QuantumCircuit(2)
    qc.h(1)
    qc.rzz(theta, 0, 1)
    qc.rz(phi, 0)
    qc.rz(phi, 1)
    qc.h(1)
    return Operator(qc)

def fidelity(theta, phi):
    return process_fidelity(build_gate(theta, phi), target=TARGET)

theta, phi = 1.0, 0.5   # initial guesses -- both need tuning simultaneously
lr = 0.5

print("Step | theta   | phi     | fidelity")
for step in range(60):
    g_theta = (fidelity(theta+0.01, phi) - fidelity(theta-0.01, phi)) / 0.02
    g_phi   = (fidelity(theta, phi+0.01) - fidelity(theta, phi-0.01)) / 0.02
    theta += lr * g_theta
    phi   += lr * g_phi
    if step % 10 == 0:
        print(f"{step:4d} | {theta:.4f}  | {phi:.4f}  | {fidelity(theta,phi):.6f}")

print(f"\nFinal: theta={theta:.4f}, phi={phi:.4f}, fidelity={fidelity(theta,phi):.6f}")
print(f"Expected theta = pi/2 = {np.pi/2:.4f}, phi = pi = {np.pi:.4f} (mod symmetries)")
assert fidelity(theta, phi) > 0.99, "2D calibration did not converge to a high-fidelity CNOT"
print("PASS: converged to a high-fidelity CNOT-equivalent gate via 2-parameter optimization.")
