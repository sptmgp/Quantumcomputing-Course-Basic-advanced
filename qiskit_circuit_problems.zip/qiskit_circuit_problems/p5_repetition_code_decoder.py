"""
Problem 5: Error correction with syndrome decoding -- a 3-qubit bit-flip
repetition code, as a deliberately simplified, honest stand-in for the full
surface code from the slide (a real surface code needs dozens of qubits and
is impractical to demonstrate end-to-end here). The core concept is
identical: ancilla qubits measure parity WITHOUT collapsing the logical
information, producing a syndrome that a decoder maps to a correction.
"""
import random
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

def build_repetition_code(error_qubit=None):
    """3 data qubits encode 1 logical qubit; 2 ancillas extract syndrome."""
    qc = QuantumCircuit(5, 2)  # qubits 0,1,2 = data; 3,4 = ancilla; 2 classical bits
    # encode |0> (all zeros) -- trivial here, but structure generalizes to |1> too
    qc.cx(0, 1)
    qc.cx(0, 2)

    if error_qubit is not None:
        qc.x(error_qubit)  # inject a bit-flip error

    # syndrome extraction: ancilla 3 checks parity(0,1), ancilla 4 checks parity(1,2)
    qc.cx(0, 3); qc.cx(1, 3)
    qc.cx(1, 4); qc.cx(2, 4)
    qc.measure(3, 0)
    qc.measure(4, 1)
    return qc

# lookup-table decoder: maps syndrome -> which data qubit to flip back
SYNDROME_TABLE = {
    (0,0): None,  # no error
    (1,0): 0,     # parity(0,1) broken only -> error on qubit 0
    (1,1): 1,     # both parities broken -> error on qubit 1
    (0,1): 2,     # parity(1,2) broken only -> error on qubit 2
}

sim = AerSimulator()

print("Injected error | Syndrome | Decoder says error on | Correct?")
correct_count = 0
for error_qubit in [None, 0, 1, 2]:
    qc = build_repetition_code(error_qubit)
    result = sim.run(qc, shots=1).result()
    counts = result.get_counts()
    bitstring = list(counts.keys())[0]
    # Qiskit bit ordering: rightmost classical bit is c[0]
    syndrome = (int(bitstring[-1]), int(bitstring[-2]))
    decoded = SYNDROME_TABLE[syndrome]
    is_correct = decoded == error_qubit
    correct_count += is_correct
    print(f"{str(error_qubit):>14} | {syndrome} | {str(decoded):>21} | {is_correct}")

print(f"\n{correct_count}/4 cases decoded correctly.")
assert correct_count == 4, "Decoder failed to correctly identify at least one error case"
print("PASS: syndrome decoding correctly identifies and locates every single-qubit bit-flip error.")
