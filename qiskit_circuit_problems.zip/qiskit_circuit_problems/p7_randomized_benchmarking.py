"""
Problem 7: Randomized Benchmarking (RB) using Qiskit Experiments, on a
noisy simulator, to extract a real error-per-Clifford (EPC) number and
verify it's close to the depolarizing rate we deliberately injected.
"""
import numpy as np
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from qiskit_experiments.library import StandardRB

# build a noisy simulator with a KNOWN depolarizing error rate,
# so we can check whether RB actually recovers something close to it
injected_error_rate = 0.01
noise_model = NoiseModel()
error_1q = depolarizing_error(injected_error_rate, 1)
noise_model.add_all_qubit_quantum_error(error_1q, ['u1', 'u2', 'u3', 'sx', 'x', 'rz'])

backend = AerSimulator(noise_model=noise_model)

lengths = [1, 5, 10, 20, 40, 70, 100]
exp = StandardRB(physical_qubits=(0,), lengths=lengths, num_samples=20, seed=42)
exp.backend = backend
result = exp.run(backend).block_for_results()

epc = result.analysis_results("EPC", dataframe=True)
epc_value = epc.iloc[0]["value"].nominal_value
print(f"Injected 1-qubit depolarizing error rate (per gate): {injected_error_rate}")
print(f"RB-extracted Error Per Clifford (EPC):                {epc_value:.5f}")
print(f"Ratio (EPC / injected per-gate rate):                 {epc_value/injected_error_rate:.2f}")
print("\nNote: EPC is not expected to exactly equal the raw per-gate rate --")
print("each random Clifford is compiled into ~1.5 physical gates on average,")
print("so some difference is expected and correct, not a bug. What matters is")
print("that EPC lands in the right order of magnitude, confirming RB actually")
print("recovers real information about the injected noise rather than noise.")

assert 0.3 < epc_value/injected_error_rate < 3.0, \
    "RB-extracted error rate is not even in the right order of magnitude -- likely a real bug"
print("\nPASS: RB recovers an EPC in the correct order of magnitude relative to the")
print("known injected noise, confirming the method works as a real fidelity tool.")
