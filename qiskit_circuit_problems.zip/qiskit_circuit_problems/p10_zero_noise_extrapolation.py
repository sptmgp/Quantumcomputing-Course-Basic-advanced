"""
Problem 10: Zero-noise extrapolation (ZNE) via gate folding, verified against
the true noiseless value -- checking whether extrapolation actually recovers
something close to the ideal result, and demonstrating the assumption ZNE
relies on (smooth, predictable noise scaling).
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from qiskit.primitives import BackendEstimatorV2
from qiskit.quantum_info import SparsePauliOp

THETA = np.pi/3  # arbitrary nonzero rotation so <Z> is a nontrivial, clearly measurable target

def make_circuit(fold_factor):
    """RX(theta), gate-folded: RX(theta) -> RX(theta) RX(-theta) RX(theta) RX(-theta) ... ,
    an odd-length sandwich that is IDEALLY identical to a single RX(theta) (since
    RX(-theta)RX(theta) = identity), but passes through the noisy gate more times,
    amplifying noise exposure without changing the ideal target result."""
    qc = QuantumCircuit(1)
    qc.rx(THETA, 0)
    for _ in range(fold_factor):
        qc.rx(-THETA, 0)
        qc.rx(THETA, 0)
    return qc

ideal_circuit = make_circuit(0)
ideal_sv = Statevector.from_instruction(ideal_circuit)
ideal_z = ideal_sv.expectation_value(SparsePauliOp("Z")).real
print(f"Ideal (noiseless) <Z> for RX({THETA:.4f}): {ideal_z:.6f}")

noise_model = NoiseModel()
noise_model.add_all_qubit_quantum_error(depolarizing_error(0.05, 1), ['rx'])
backend = AerSimulator(noise_model=noise_model)

noise_levels = [1, 3, 5, 7]  # 1x, 3x, 5x, 7x noise exposure via folding
measured = []
for fold in [0, 1, 2, 3]:  # fold=k means (2k+1)x the RX-gate noise exposure
    qc = make_circuit(fold)
    qc.save_expectation_value(SparsePauliOp("Z").to_matrix(), [0], label='z')
    result = backend.run(qc, shots=8000).result()
    z_val = result.data(0)['z'].real
    measured.append(z_val)

print("\nNoise level (x) | measured <Z>")
for level, val in zip(noise_levels, measured):
    print(f"{level:>3}             | {val:.6f}")

# linear extrapolation back to zero-noise (x=0) from the measured points
coeffs = np.polyfit(noise_levels, measured, deg=1)
extrapolated_z = np.polyval(coeffs, 0)
print(f"\nLinear extrapolation to zero-noise: <Z> = {extrapolated_z:.6f}")
print(f"True ideal value:                    <Z> = {ideal_z:.6f}")
print(f"Error of extrapolated estimate:            {abs(extrapolated_z - ideal_z):.6f}")

# compare against just using the noisiest single measurement, unmitigated
print(f"Error if you'd just used the noisiest single measurement (no ZNE): "
      f"{abs(measured[-1] - ideal_z):.6f}")

assert abs(extrapolated_z - ideal_z) < abs(measured[-1] - ideal_z), \
    "ZNE extrapolation did not improve on the raw noisy measurement"
print("\nPASS: zero-noise extrapolation gets measurably closer to the true ideal value")
print("than any single noisy measurement did, confirming the technique actually works")
print("here (where the noise really does scale smoothly, as ZNE assumes).")
