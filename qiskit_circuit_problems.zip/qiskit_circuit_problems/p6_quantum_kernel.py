"""
Problem 6: Quantum feature map for classification, compared honestly against
a classical kernel on the same toy dataset -- to actually check the honest
caveat from the problem: does the quantum kernel actually win here, or not?
"""
import numpy as np
from qiskit.circuit.library import zz_feature_map
from qiskit.quantum_info import Statevector
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_moons
from sklearn.metrics import accuracy_score

np.random.seed(42)
X, y = make_moons(n_samples=80, noise=0.15, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

feature_map = zz_feature_map(feature_dimension=2, reps=2)

def quantum_kernel_matrix(A, B):
    """Fidelity-based quantum kernel: K(x,y) = |<phi(x)|phi(y)>|^2."""
    statevecs_A = [Statevector.from_instruction(feature_map.assign_parameters(x)) for x in A]
    statevecs_B = [Statevector.from_instruction(feature_map.assign_parameters(x)) for x in B]
    K = np.zeros((len(A), len(B)))
    for i, sa in enumerate(statevecs_A):
        for j, sb in enumerate(statevecs_B):
            K[i, j] = abs(sa.inner(sb))**2
    return K

print("Computing quantum kernel matrices (this maps each point through the circuit)...")
K_train = quantum_kernel_matrix(X_train, X_train)
K_test = quantum_kernel_matrix(X_test, X_train)

qsvm = SVC(kernel="precomputed")
qsvm.fit(K_train, y_train)
q_acc = accuracy_score(y_test, qsvm.predict(K_test))

# honest classical baseline on the SAME data
rbf_svm = SVC(kernel="rbf")
rbf_svm.fit(X_train, y_train)
c_acc = accuracy_score(y_test, rbf_svm.predict(X_test))

print(f"\nQuantum kernel SVM accuracy:  {q_acc:.3f}")
print(f"Classical RBF kernel accuracy: {c_acc:.3f}")
print("\nHonest takeaway: on an easy, low-dimensional dataset like this, classical")
print("kernels are expected to do just as well or better -- this is exactly the")
print("caveat from the problem. Quantum kernels are NOT shown here to win; the")
print("point of this script is to let you verify that claim yourself instead of")
print("taking it on faith.")
print("\nCOMPLETE: both kernels evaluated on identical train/test splits, no cherry-picking.")
