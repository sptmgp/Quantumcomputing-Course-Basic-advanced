"""
Problem 9: Multi-segment pulse shape optimization, demonstrating the actual
2N-evaluation-per-step cost claim from the problem as N (segments) grows --
the concrete, measured version of "why finite differences don't scale, and
why a learned policy (RL) is used instead in practice."
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

def gate_fidelity_multisegment(amplitudes):
    """A pulse discretized into len(amplitudes) segments, each contributing
    a small RX rotation; total rotation should reach pi for a perfect X gate."""
    qc = QuantumCircuit(1)
    for amp in amplitudes:
        qc.rx(amp, 0)
    sv = Statevector.from_instruction(qc)
    target = Statevector.from_label('1')
    return abs(sv.inner(target))**2

def finite_difference_gradient(amplitudes, h=0.01):
    """Centered finite differences -- costs 2 evaluations PER segment."""
    grad = np.zeros_like(amplitudes)
    eval_count = 0
    for i in range(len(amplitudes)):
        plus = amplitudes.copy(); plus[i] += h
        minus = amplitudes.copy(); minus[i] -= h
        grad[i] = (gate_fidelity_multisegment(plus) - gate_fidelity_multisegment(minus)) / (2*h)
        eval_count += 2
    return grad, eval_count

print("N segments | evaluations per optimization step (measured, not estimated)")
for N in [1, 2, 5, 10, 20, 50]:
    amps = np.full(N, np.pi/(2*N))  # arbitrary starting point
    _, eval_count = finite_difference_gradient(amps)
    print(f"{N:>10} | {eval_count}")

# actually run the optimization for a modest N to confirm it still converges correctly
N = 5
amps = np.full(N, 0.3)
lr = 0.5
total_evals = 0
for step in range(60):
    grad, evals = finite_difference_gradient(amps)
    amps += lr * grad
    total_evals += evals

final_fidelity = gate_fidelity_multisegment(amps)
print(f"\nWith N={N} segments: final fidelity = {final_fidelity:.6f}, "
      f"total Hamiltonian evaluations used = {total_evals}")
print(f"(compare to Problem 1's single-parameter case, which used only 2 evaluations per step)")

assert final_fidelity > 0.99, "Multi-segment optimization did not converge"
print("\nPASS: confirms the cost scales linearly with N (2N per step) exactly as claimed,")
print("and that this cost becomes the real, measured motivation for using a trained")
print("policy network (RL) instead of finite differences as N grows large.")
