"""
Problem 1: Rabi calibration of a pi-pulse (X gate) -- Qiskit version.
Mirrors the original QuTiP-based slide, using Qiskit's RXGate and Statevector
simulation instead. Calibrates the rotation angle theta so that RX(theta)
acts as a perfect X gate (|0> -> |1>), via finite-difference gradient ascent
-- the same method as the original slide, just in Qiskit.
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

def gate_fidelity(theta):
    """Fidelity of RX(theta)|0> against the target state |1>."""
    qc = QuantumCircuit(1)
    qc.rx(theta, 0)
    sv = Statevector.from_instruction(qc)
    target = Statevector.from_label('1')
    return abs(sv.inner(target))**2  # |<target|psi>|^2

theta = 1.0  # initial guess (radians), analogous to the slide's amp=1.0
lr = 0.3

print("Step | theta    | fidelity")
for step in range(40):
    grad = (gate_fidelity(theta + 0.01) - gate_fidelity(theta - 0.01)) / 0.02
    theta += lr * grad
    if step % 5 == 0:
        print(f"{step:4d} | {theta:.4f}   | {gate_fidelity(theta):.6f}")

print(f"\nConverged theta = {theta:.6f}  (target: pi = {np.pi:.6f})")
print(f"Final fidelity  = {gate_fidelity(theta):.8f}")
assert abs(theta - np.pi) < 0.02, "Did not converge to pi as expected"
print("PASS: theta converged to pi within tolerance.")
