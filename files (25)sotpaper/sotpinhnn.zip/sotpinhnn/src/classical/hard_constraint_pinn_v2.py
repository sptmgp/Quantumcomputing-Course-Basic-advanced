"""
Hard-constraint PINN, vectorized (fixes v1's slow per-timestep Python loop).

Single batched forward pass per epoch: N_t sampled times x N_SPATIAL fixed
grid points, normalized via per-time-group sum (the "partition function"
Z(t)), then PDE residual computed via ONE set of autograd.grad calls over
the whole batch instead of looping with create_graph=True per timestep.
"""
import numpy as np
import torch
import torch.nn as nn
import time

torch.manual_seed(0)

def Vprime_t(q): return -q + 4*q**3/100.0
q0, p0, sigma = 1.0, 0.0, 1.0
DOMAIN = 15.0

class RawNet(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
            nn.Softplus(),  # positivity by construction -- also fixes negative-density failure
        )
    def forward(self, x):
        return self.net(x)

N_GRID = 14
qs_train = torch.linspace(-DOMAIN, DOMAIN, N_GRID)
ps_train = torch.linspace(-DOMAIN, DOMAIN, N_GRID)
Qg_train, Pg_train = torch.meshgrid(qs_train, ps_train, indexing='ij')
Qg_flat = Qg_train.flatten().view(-1, 1)
Pg_flat = Pg_train.flatten().view(-1, 1)
dq_train = (2*DOMAIN) / (N_GRID - 1)
dp_train = dq_train
N_SPATIAL = Qg_flat.shape[0]

model = RawNet(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

N_T = 8
EPOCHS = 600

print("Training hard-constraint PINN (vectorized)...")
t_start = time.time()
for epoch in range(EPOCHS):
    opt.zero_grad()

    t_rand = torch.rand(N_T - 1, 1)
    t_vals = torch.cat([torch.zeros(1,1), t_rand], dim=0)  # (N_T,1), t=0 always included

    q_batch = Qg_flat.repeat(N_T, 1).requires_grad_(True)          # (N_T*N_SPATIAL,1)
    p_batch = Pg_flat.repeat(N_T, 1).requires_grad_(True)
    t_batch = t_vals.repeat_interleave(N_SPATIAL, dim=0).requires_grad_(True)  # (N_T*N_SPATIAL,1)

    raw = model(torch.cat([q_batch, p_batch, t_batch], dim=1))     # (N_T*N_SPATIAL,1)
    raw_grouped = raw.view(N_T, N_SPATIAL)
    Z = raw_grouped.sum(dim=1, keepdim=True) * dq_train * dp_train + 1e-12  # (N_T,1)
    Z_expanded = Z.repeat_interleave(N_SPATIAL, dim=0)             # (N_T*N_SPATIAL,1)
    rho = raw / Z_expanded

    drho_dq = torch.autograd.grad(rho, q_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho, p_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dt = torch.autograd.grad(rho, t_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]

    residual = drho_dt + p_batch*drho_dq - Vprime_t(q_batch)*drho_dp
    loss_pde = torch.mean(residual**2)

    # IC loss: first N_SPATIAL rows correspond to t=0
    rho_t0 = rho[:N_SPATIAL]
    q0_grid, p0_grid = Qg_flat, Pg_flat
    rho0_target = torch.exp(-((q0_grid-q0)**2 + (p0_grid-p0)**2)/(2*sigma**2)) / (2*np.pi*sigma**2)
    loss_ic = torch.mean((rho_t0 - rho0_target)**2)

    loss = loss_pde + 50*loss_ic
    loss.backward()
    opt.step()

    if epoch % 100 == 0:
        print(epoch, "loss:", float(loss.item()), "pde:", float(loss_pde.item()), "ic:", float(loss_ic.item()),
              "Z(t=0):", float(Z[0].item()))

train_time = time.time() - t_start
print("Training time:", train_time, "s")
torch.save(model.state_dict(), 'hard_constraint_model.pt')
print("saved")
