"""
Ground-truth reference for the Liouville transport equation under the
quartic double-well Hamiltonian from Gomez et al. (2014), Sec 3:

    H0 = p^2/2 - q^2/2 + q^4/100   (m = omega0 = D = 1)

Since this Hamiltonian flow is non-dissipative, Liouville's theorem gives an
EXACT reference via the method of characteristics:
    rho(q, p, t) = rho0( Phi_{-t}(q, p) )
where Phi_t is the Hamiltonian flow map. We integrate Hamilton's equations
backward in time from every grid point to find where it came from, then
evaluate the known initial Gaussian there. This avoids needing our own
from-scratch FFT split-operator reimplementation to trust as ground truth.
"""
import numpy as np

def V(q):
    return -0.5*q**2 + (q**4)/100.0

def Vprime(q):
    return -q + 4*q**3/100.0

def hamilton_rhs(state):
    q, p = state
    return np.array([p, -Vprime(q)])

def rk4_step(state, dt):
    k1 = hamilton_rhs(state)
    k2 = hamilton_rhs(state + 0.5*dt*k1)
    k3 = hamilton_rhs(state + 0.5*dt*k2)
    k4 = hamilton_rhs(state + dt*k3)
    return state + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)

def integrate_backward(Q, P, t, n_steps=200):
    """Integrate Hamilton's equations backward by time t, vectorized over grid."""
    dt = -t / n_steps
    state = np.stack([Q, P])
    for _ in range(n_steps):
        state = rk4_step(state, dt)
    return state[0], state[1]

def initial_gaussian(q, p, q0=1.0, p0=0.0, sigma=1.0):
    return np.exp(-((q-q0)**2 + (p-p0)**2) / (2*sigma**2)) / (2*np.pi*sigma**2)

def reference_density(Qgrid, Pgrid, t, q0=1.0, p0=0.0, sigma=1.0):
    Q0, P0 = integrate_backward(Qgrid, Pgrid, t)
    return initial_gaussian(Q0, P0, q0, p0, sigma)

if __name__ == "__main__":
    n = 128
    qs = np.linspace(-15, 15, n)
    ps = np.linspace(-15, 15, n)
    Q, P = np.meshgrid(qs, ps)

    import time
    t0 = time.time()
    rho_t1 = reference_density(Q, P, t=1.0)
    elapsed = time.time() - t0
    print("reference computed, elapsed:", elapsed, "s, grid", n, "x", n)
    print("mass check (should be near 1, up to grid discretization):",
          np.sum(rho_t1) * (qs[1]-qs[0]) * (ps[1]-ps[0]))
    np.save('rho_ref_t1.npy', rho_t1)
    np.save('Q.npy', Q)
    np.save('P.npy', P)
