import numpy as np
import torch, torch.nn as nn, json

def V(q): return -0.5*q**2 + (q**4)/100.0
def Vprime_t(q): return -q + 4*q**3/100.0

configs = {
    'deep_well':   dict(q0=4.0, p0=0.0, sigma=0.7),
    'mid_well':    dict(q0=1.0, p0=0.0, sigma=1.0),
    'near_sep':    dict(q0=0.2, p0=0.3, sigma=0.5),
}
for name, c in configs.items():
    c['energy'] = 0.5*c['p0']**2 + V(c['q0'])
    print(name, 'H =', c['energy'])

class PINN(nn.Module):
    def __init__(self, hidden=48):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q,p,t): return self.net(torch.cat([q,p,t], dim=1))

def sample_collocation(n):
    q=(torch.rand(n,1)*30-15).requires_grad_(True)
    p=(torch.rand(n,1)*30-15).requires_grad_(True)
    t=(torch.rand(n,1)*1.0).requires_grad_(True)
    return q,p,t

def sample_ic(n, q0, p0, sigma):
    q=torch.randn(n,1)*3*sigma+q0; p=torch.randn(n,1)*3*sigma+p0; t=torch.zeros(n,1)
    rho0=torch.exp(-((q-q0)**2+(p-p0)**2)/(2*sigma**2))/(2*np.pi*sigma**2)
    return q,p,t,rho0

from reference_solution import reference_density
Qs = np.linspace(-15,15,128); Ps = np.linspace(-15,15,128)
Qg, Pg = np.meshgrid(Qs, Ps)
dq = 30/127; dp = dq

results = {}
for name, c in configs.items():
    torch.manual_seed(0)
    model = PINN(hidden=48)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    for epoch in range(700):
        opt.zero_grad()
        q,p,t = sample_collocation(1000)
        rho = model(q,p,t)
        drho_dt = torch.autograd.grad(rho,t,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        drho_dq = torch.autograd.grad(rho,q,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        drho_dp = torch.autograd.grad(rho,p,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
        loss_pde = torch.mean(residual**2)
        q_ic,p_ic,t_ic,rho0_t = sample_ic(500, c['q0'], c['p0'], c['sigma'])
        loss_ic = torch.mean((model(q_ic,p_ic,t_ic)-rho0_t)**2)
        loss = loss_pde + 50*loss_ic
        loss.backward(); opt.step()

    Qt = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
    Pt = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
    Tt = torch.ones_like(Qt)
    with torch.no_grad():
        pred = model(Qt, Pt, Tt).numpy().reshape(Qg.shape)

    ref = reference_density(Qg, Pg, t=1.0, q0=c['q0'], p0=c['p0'], sigma=c['sigma'])
    mass_ref = np.sum(ref)*dq*dp
    mass_pred = np.sum(pred)*dq*dp
    mse = np.mean((pred-ref)**2)
    results[name] = dict(energy=c['energy'], mass_ref=float(mass_ref), mass_pred=float(mass_pred),
                          mse=float(mse), final_loss=float(loss.item()))
    print(name, results[name])
    np.save(f'sep_pred_{name}.npy', pred)
    np.save(f'sep_ref_{name}.npy', ref)

with open('separatrix_results.json','w') as f:
    json.dump(results, f, indent=2)
np.save('sep_Q.npy', Qg); np.save('sep_P.npy', Pg)
print("saved separatrix_results.json")
