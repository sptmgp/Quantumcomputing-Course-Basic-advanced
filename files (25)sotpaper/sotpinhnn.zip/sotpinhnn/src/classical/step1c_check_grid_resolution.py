import numpy as np
import time
from step1_exact_multikick import invert_one_period, q0, p0, sigma
from reference_solution import initial_gaussian

for n in [60, 100, 150, 220]:
    qs = np.linspace(-15, 15, n)
    ps = np.linspace(-15, 15, n)
    Q, P = np.meshgrid(qs, ps)
    dq = qs[1]-qs[0]; dp = ps[1]-ps[0]
    Qc, Pc = Q.copy(), P.copy()
    t0 = time.time()
    for _ in range(5):
        Qc, Pc = invert_one_period(Qc, Pc, n_substeps=60)
    rho = initial_gaussian(Qc, Pc, q0, p0, sigma)
    mass = np.sum(rho)*dq*dp
    print(f"grid={n}x{n}: 5-period mass={mass:.6f}, time={time.time()-t0:.2f}s")
