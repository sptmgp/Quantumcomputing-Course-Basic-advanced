"""
Multi-seed robustness test: retrain the HNN with 5 different random seeds,
propagate each through the actual chaotic multi-kick map, and report
mean +/- std error -- directly analogous to repeated-trial error bars in
real quantum hardware experiments (cf. uploaded Fig. 6), and closing the
"single random seed" limitation flagged in the paper's Discussion.
"""
import numpy as np
import torch
import torch.nn as nn
import time
from reference_solution import rk4_step, initial_gaussian
from step1_exact_multikick import invert_one_period

def V(q): return -0.5*q**2 + (q**4)/100.0
def Vprime_true(q): return -q + 4*q**3/100.0
def true_rhs(q, p): return p, -Vprime_true(q)

KICK_SHIFT = 0.5
q0, p0, sigma = 1.0, 0.0, 1.0

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

def train_hnn(seed, n_train=2000, domain=10.0, epochs=2000):
    torch.manual_seed(seed)
    np.random.seed(seed)
    q_train = (np.random.rand(n_train)*2-1)*domain
    p_train = (np.random.rand(n_train)*2-1)*domain
    qdot_train, pdot_train = true_rhs(q_train, p_train)
    model = HNN(hidden=64)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    q_t = torch.tensor(q_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
    p_t = torch.tensor(p_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
    qdot_t = torch.tensor(qdot_train, dtype=torch.float32).view(-1,1)
    pdot_t = torch.tensor(pdot_train, dtype=torch.float32).view(-1,1)
    for epoch in range(epochs):
        opt.zero_grad()
        H = model(q_t, p_t)
        dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
        dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
        loss = torch.mean((dH_dp - qdot_t)**2) + torch.mean((-dH_dq - pdot_t)**2)
        loss.backward()
        opt.step()
    return model, float(loss.item())

def learned_rhs_batch(model, Q, P):
    q_t = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    p_t = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    H = model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), retain_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), retain_graph=False)[0]
    qdot = dH_dp.detach().numpy().reshape(Q.shape)
    pdot = -dH_dq.detach().numpy().reshape(P.shape)
    return qdot, pdot

def invert_one_period_learned(model, Q, P, n_substeps=50):
    dt = -1.0 / n_substeps
    state = (Q.copy(), P.copy())
    for _ in range(n_substeps):
        Qc, Pc = state
        k1q,k1p = learned_rhs_batch(model,Qc,Pc)
        k2q,k2p = learned_rhs_batch(model,Qc+0.5*dt*k1q,Pc+0.5*dt*k1p)
        k3q,k3p = learned_rhs_batch(model,Qc+0.5*dt*k2q,Pc+0.5*dt*k2p)
        k4q,k4p = learned_rhs_batch(model,Qc+dt*k3q,Pc+dt*k3p)
        Qn = Qc + (dt/6.0)*(k1q+2*k2q+2*k3q+k4q)
        Pn = Pc + (dt/6.0)*(k1p+2*k2p+2*k3p+k4p)
        state = (Qn,Pn)
    Q_postkick, P_postkick = state
    return Q_postkick, P_postkick + KICK_SHIFT

n = 90
qs = np.linspace(-15,15,n); ps = np.linspace(-15,15,n)
Qg, Pg = np.meshgrid(qs,ps)
dq = qs[1]-qs[0]; dp = ps[1]-ps[0]

print("Building exact chaotic reference (once)...")
Qe, Pe = Qg.copy(), Pg.copy()
exact_by_period = {}
for period in range(1,5):
    Qe, Pe = invert_one_period(Qe, Pe, n_substeps=50)
    exact_by_period[period] = initial_gaussian(Qe, Pe, q0, p0, sigma)

SEEDS = [0, 1, 2, 3, 4]
mse_by_seed = {s: [] for s in SEEDS}

for seed in SEEDS:
    t0 = time.time()
    model, final_loss = train_hnn(seed)
    Qh, Ph = Qg.copy(), Pg.copy()
    for period in range(1,5):
        Qh, Ph = invert_one_period_learned(model, Qh, Ph, n_substeps=50)
        rho_h = initial_gaussian(Qh, Ph, q0, p0, sigma)
        mse = np.mean((rho_h - exact_by_period[period])**2)
        mse_by_seed[seed].append(mse)
    print(f"seed={seed}: final_loss={final_loss:.3f}, mse_by_period={mse_by_seed[seed]}, time={time.time()-t0:.1f}s")

np.save('mse_by_seed.npy', np.array([mse_by_seed[s] for s in SEEDS]))
print("saved mse_by_seed.npy, shape:", np.array([mse_by_seed[s] for s in SEEDS]).shape)
