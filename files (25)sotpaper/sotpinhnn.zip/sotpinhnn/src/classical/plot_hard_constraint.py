import numpy as np
import matplotlib.pyplot as plt

Q = np.load('Q.npy'); P = np.load('P.npy')
ref = np.load('rho_ref_t1.0.npy')
pred = np.load('hc_pred_t1_fine.npy')

fig, axes = plt.subplots(1, 3, figsize=(15,4.3))
vmax = max(ref.max(), pred.max())

im0 = axes[0].pcolormesh(Q, P, ref, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
axes[0].set_title('Exact reference\nrho(q,p,t=1)')
axes[0].set_xlabel('q'); axes[0].set_ylabel('p')
plt.colorbar(im0, ax=axes[0])

im1 = axes[1].pcolormesh(Q, P, pred, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
axes[1].set_title('Hard-constraint PINN\n(mass=1.0000, positive by construction)')
axes[1].set_xlabel('q'); axes[1].set_ylabel('p')
plt.colorbar(im1, ax=axes[1])

diff = pred - ref
im2 = axes[2].pcolormesh(Q, P, diff, shading='auto', cmap='RdBu_r',
                           vmin=-np.max(np.abs(diff)), vmax=np.max(np.abs(diff)))
axes[2].set_title('Difference (PINN - exact)')
axes[2].set_xlabel('q'); axes[2].set_ylabel('p')
plt.colorbar(im2, ax=axes[2])

plt.tight_layout()
plt.savefig('hard_constraint_comparison.png', dpi=150)
print("saved")

# quantify: does it capture the shearing (elongation) or stay a round blob?
# compute the covariance matrix of each distribution to check for elongation/tilt
def moments(rho, Q, P, dq, dp):
    mass = np.sum(rho)*dq*dp
    qbar = np.sum(Q*rho)*dq*dp/mass
    pbar = np.sum(P*rho)*dq*dp/mass
    cov_qq = np.sum((Q-qbar)**2*rho)*dq*dp/mass
    cov_pp = np.sum((P-pbar)**2*rho)*dq*dp/mass
    cov_qp = np.sum((Q-qbar)*(P-pbar)*rho)*dq*dp/mass
    return qbar, pbar, cov_qq, cov_pp, cov_qp

dq = 30/127
qbar_e, pbar_e, cqq_e, cpp_e, cqp_e = moments(ref, Q, P, dq, dq)
qbar_p, pbar_p, cqq_p, cpp_p, cqp_p = moments(pred, Q, P, dq, dq)
print(f"Exact:  mean=({qbar_e:.2f},{pbar_e:.2f}) cov_qq={cqq_e:.3f} cov_pp={cpp_e:.3f} cov_qp={cqp_e:.3f}")
print(f"PINN:   mean=({qbar_p:.2f},{pbar_p:.2f}) cov_qq={cqq_p:.3f} cov_pp={cpp_p:.3f} cov_qp={cqp_p:.3f}")
print(f"(cov_qp far from 0 = sheared/tilted distribution; exact should show strong shear)")
