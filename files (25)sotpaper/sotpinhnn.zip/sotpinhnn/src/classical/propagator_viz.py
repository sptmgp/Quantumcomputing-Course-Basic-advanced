import numpy as np
import torch, torch.nn as nn
import matplotlib.pyplot as plt
from reference_solution import hamilton_rhs, rk4_step, Vprime

# ---------- Panel A: exact phase propagator (flow field + real trajectories) ----------
qs = np.linspace(-8, 8, 25)
ps = np.linspace(-8, 8, 25)
Qg, Pg = np.meshgrid(qs, ps)
dQ = Pg
dP = -Vprime(Qg)
speed = np.sqrt(dQ**2 + dP**2)

# launch a ring of particles around the initial Gaussian (q0,p0)=(1,0), sigma=1
np.random.seed(0)
n_particles = 14
angles = np.linspace(0, 2*np.pi, n_particles, endpoint=False)
q0s = 1.0 + 1.0*np.cos(angles)
p0s = 0.0 + 1.0*np.sin(angles)

n_steps = 400
dt = 1.0/n_steps
trajectories = []
for q0, p0 in zip(q0s, p0s):
    state = np.array([q0, p0])
    path = [state.copy()]
    for _ in range(n_steps):
        state = rk4_step(state, dt)
        path.append(state.copy())
    trajectories.append(np.array(path))

# ---------- Panel B: PINN "propagator" -- retrain the same baseline quickly ----------
torch.manual_seed(0)
def Vprime_t(q): return -q + 4*q**3/100.0
q0c, p0c, sigma = 1.0, 0.0, 1.0

class PINN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p, t):
        return self.net(torch.cat([q,p,t], dim=1))

def sample_collocation(n):
    q=(torch.rand(n,1)*30-15).requires_grad_(True)
    p=(torch.rand(n,1)*30-15).requires_grad_(True)
    t=(torch.rand(n,1)*1.0).requires_grad_(True)
    return q,p,t
def sample_ic(n):
    q=torch.randn(n,1)*3+q0c; p=torch.randn(n,1)*3+p0c; t=torch.zeros(n,1)
    rho0=torch.exp(-((q-q0c)**2+(p-p0c)**2)/(2*sigma**2))/(2*np.pi*sigma**2)
    return q,p,t,rho0

model = PINN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
for epoch in range(1200):
    opt.zero_grad()
    q,p,t = sample_collocation(1500)
    rho = model(q,p,t)
    drho_dt = torch.autograd.grad(rho,t,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dq = torch.autograd.grad(rho,q,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho,p,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
    loss_pde = torch.mean(residual**2)
    q_ic,p_ic,t_ic,rho0_t = sample_ic(800)
    loss_ic = torch.mean((model(q_ic,p_ic,t_ic)-rho0_t)**2)
    loss = loss_pde + 50*loss_ic
    loss.backward(); opt.step()
print("PINN retrained, final loss:", float(loss.item()))

Q = np.load('Q.npy'); P = np.load('P.npy')
Qt = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1)
Pt = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1)
snap_times = [0.0, 0.25, 0.5, 0.75, 1.0]
pinn_snaps = []
for tv in snap_times:
    Tt = torch.full_like(Qt, tv)
    with torch.no_grad():
        pred = model(Qt, Pt, Tt).numpy().reshape(Q.shape)
    pinn_snaps.append(pred)

# ---------- Build the combined figure ----------
fig = plt.figure(figsize=(15, 7))
gs = fig.add_gridspec(2, 5, height_ratios=[2.2,1])

axA = fig.add_subplot(gs[0, :])
axA.streamplot(Qg, Pg, dQ, dP, color=speed, cmap='Greys', density=1.1, linewidth=0.6, arrowsize=0.8)
cmap = plt.cm.plasma
for i, traj in enumerate(trajectories):
    axA.plot(traj[:,0], traj[:,1], color=cmap(i/len(trajectories)), linewidth=1.4, alpha=0.9)
    axA.scatter(traj[0,0], traj[0,1], color='blue', s=25, zorder=5)
    axA.scatter(traj[-1,0], traj[-1,1], color='red', s=25, zorder=5)
axA.scatter([], [], color='blue', s=25, label='t=0 (initial particles)')
axA.scatter([], [], color='red', s=25, label='t=1 (propagated)')
axA.set_xlim(-8,8); axA.set_ylim(-8,8)
axA.set_xlabel('q'); axA.set_ylabel('p')
axA.set_title('Exact phase propagator: Hamiltonian flow field + real particle trajectories\n'
              r'$\dot q = p,\ \dot p = -V\'(q)$ -- each particle follows an exact deterministic path')
axA.legend(loc='upper right')

vmax = max(s.max() for s in pinn_snaps)
for i, (tv, snap) in enumerate(zip(snap_times, pinn_snaps)):
    ax = fig.add_subplot(gs[1, i])
    ax.pcolormesh(Q, P, snap, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
    ax.set_title(f't={tv}', fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    if i == 0:
        ax.set_ylabel('PINN\nrho(q,p,t)', fontsize=9)

fig.suptitle('Two propagators for the same double-well phase space', fontsize=13, y=1.02)
plt.tight_layout()
plt.savefig('propagator_comparison.png', dpi=150, bbox_inches='tight')
print("saved propagator_comparison.png")
