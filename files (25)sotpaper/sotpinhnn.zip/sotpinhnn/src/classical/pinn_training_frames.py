"""
Train the original (failing) density-regression PINN, saving a snapshot
of its predicted density at t=1 every 100 epochs, to animate the training
process itself -- watching it NOT converge to the correct conserved shape.
"""
import numpy as np
import torch
import torch.nn as nn
from reference_solution import initial_gaussian

torch.manual_seed(0)
def Vprime_t(q): return -q + 4*q**3/100.0
q0c, p0c, sigma = 1.0, 0.0, 1.0

class PINN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p, t): return self.net(torch.cat([q,p,t], dim=1))

def sample_collocation(n):
    q=(torch.rand(n,1)*30-15).requires_grad_(True)
    p=(torch.rand(n,1)*30-15).requires_grad_(True)
    t=(torch.rand(n,1)*1.0).requires_grad_(True)
    return q,p,t
def sample_ic(n):
    q=torch.randn(n,1)*3+q0c; p=torch.randn(n,1)*3+p0c; t=torch.zeros(n,1)
    rho0=torch.exp(-((q-q0c)**2+(p-p0c)**2)/(2*sigma**2))/(2*np.pi*sigma**2)
    return q,p,t,rho0

model = PINN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

n_grid = 80
qs = np.linspace(-15,15,n_grid); ps = np.linspace(-15,15,n_grid)
Qg, Pg = np.meshgrid(qs,ps)
Qt = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
Pt = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
Tt = torch.ones_like(Qt)

frames = []
masses = []
epochs_saved = []
dq = 30/(n_grid-1)

N_EPOCHS = 1500
SAVE_EVERY = 50

for epoch in range(N_EPOCHS+1):
    opt.zero_grad()
    q,p,t = sample_collocation(1500)
    rho = model(q,p,t)
    drho_dt = torch.autograd.grad(rho,t,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dq = torch.autograd.grad(rho,q,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho,p,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
    loss_pde = torch.mean(residual**2)
    q_ic,p_ic,t_ic,rho0_t = sample_ic(800)
    loss_ic = torch.mean((model(q_ic,p_ic,t_ic)-rho0_t)**2)
    loss = loss_pde + 50*loss_ic
    loss.backward()
    opt.step()

    if epoch % SAVE_EVERY == 0:
        with torch.no_grad():
            pred = model(Qt,Pt,Tt).numpy().reshape(Qg.shape)
        mass = np.sum(pred)*dq*dq
        frames.append(pred.copy())
        masses.append(mass)
        epochs_saved.append(epoch)
        if epoch % 300 == 0:
            print(f"epoch {epoch}: loss={float(loss.item()):.4f}, mass={mass:.3f}")

np.savez('pinn_training_frames.npz', frames=np.array(frames), masses=np.array(masses),
         epochs=np.array(epochs_saved), Q=Qg, P=Pg)
print("saved", len(frames), "frames")
