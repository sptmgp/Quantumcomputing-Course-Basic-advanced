"""
STEP 3: Final, matched comparison -- exact vs HNN-based propagation
through the actual chaotic multi-kick map, same grid, same substep count,
same number of periods, for a fair test.
"""
import numpy as np
import time
from step1_exact_multikick import invert_one_period
from step2_hnn_multikick import invert_one_period_learned, initial_gaussian
from reference_solution import initial_gaussian as ig_exact

q0, p0, sigma = 1.0, 0.0, 1.0
N_GRID = 120
N_SUBSTEPS = 50
N_PERIODS = 4

qs = np.linspace(-15, 15, N_GRID)
ps = np.linspace(-15, 15, N_GRID)
Q, P = np.meshgrid(qs, ps)
dq = qs[1]-qs[0]; dp = ps[1]-ps[0]
np.save('Q_final.npy', Q); np.save('P_final.npy', P)

print("=== EXACT dynamics ===")
Qe, Pe = Q.copy(), P.copy()
exact_results = {}
for period in range(1, N_PERIODS+1):
    t0 = time.time()
    Qe, Pe = invert_one_period(Qe, Pe, n_substeps=N_SUBSTEPS)
    rho = ig_exact(Qe, Pe, q0, p0, sigma)
    mass = np.sum(rho)*dq*dp
    print(f"period {period}: mass={mass:.5f}, time={time.time()-t0:.2f}s")
    exact_results[period] = rho
    np.save(f'rho_exact_final_{period}.npy', rho)

print("=== HNN-learned dynamics ===")
Qh, Ph = Q.copy(), P.copy()
hnn_results = {}
for period in range(1, N_PERIODS+1):
    t0 = time.time()
    Qh, Ph = invert_one_period_learned(Qh, Ph, n_substeps=N_SUBSTEPS)
    rho = initial_gaussian(Qh, Ph, q0, p0, sigma)
    mass = np.sum(rho)*dq*dp
    print(f"period {period}: mass={mass:.5f}, time={time.time()-t0:.2f}s")
    hnn_results[period] = rho
    np.save(f'rho_hnn_final_{period}.npy', rho)

print("=== Comparison metrics ===")
for period in range(1, N_PERIODS+1):
    ref = exact_results[period]
    pred = hnn_results[period]
    mse = np.mean((pred-ref)**2)
    print(f"period {period}: MSE(HNN vs exact) = {mse:.3e}")
