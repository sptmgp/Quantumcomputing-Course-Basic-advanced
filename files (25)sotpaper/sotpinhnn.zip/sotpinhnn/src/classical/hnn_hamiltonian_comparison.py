"""
New HNN visualizations, not phase-space trajectories:
(1) The learned Hamiltonian H_theta(q,p) vs the true H_0(q,p), as contour maps.
(2) The learned vector field vs the true vector field, as quiver plots.
"""
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

def V(q): return -0.5*q**2 + (q**4)/100.0
def Vprime(q): return -q + 4*q**3/100.0
def H_true(q, p): return 0.5*p**2 + V(q)

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

model = HNN(hidden=64)
model.load_state_dict(torch.load('/home/claude/chaos_pinn/hnn/hnn_model.pt'))

qs = np.linspace(-8, 8, 80)
ps = np.linspace(-8, 8, 80)
Qg, Pg = np.meshgrid(qs, ps)

qt = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
pt = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
with torch.no_grad():
    H_learned = model(qt, pt).numpy().reshape(Qg.shape)

H_exact = H_true(Qg, Pg)

# H is only defined up to an additive constant -- match means before comparing
H_learned_shifted = H_learned - H_learned.mean() + H_exact.mean()

# ---------- Figure 1: Hamiltonian contour comparison ----------
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
levels = np.linspace(min(H_exact.min(), H_learned_shifted.min()),
                       max(H_exact.max(), H_learned_shifted.max()), 20)

c0 = axes[0].contourf(Qg, Pg, H_exact, levels=levels, cmap='RdYlBu_r')
axes[0].set_title('True Hamiltonian $H_0(q,p)$')
axes[0].set_xlabel('q'); axes[0].set_ylabel('p')
plt.colorbar(c0, ax=axes[0])

c1 = axes[1].contourf(Qg, Pg, H_learned_shifted, levels=levels, cmap='RdYlBu_r')
axes[1].set_title(r'Learned $H_\theta(q,p)$ (mean-matched)')
axes[1].set_xlabel('q'); axes[1].set_ylabel('p')
plt.colorbar(c1, ax=axes[1])

diff = H_learned_shifted - H_exact
c2 = axes[2].contourf(Qg, Pg, diff, levels=20, cmap='RdBu_r')
axes[2].set_title('Difference (learned $-$ true)')
axes[2].set_xlabel('q'); axes[2].set_ylabel('p')
plt.colorbar(c2, ax=axes[2])

plt.tight_layout()
plt.savefig('hnn_hamiltonian_comparison.png', dpi=150)
plt.close()
print("saved hnn_hamiltonian_comparison.png")
print("Hamiltonian RMS error (mean-matched):", np.sqrt(np.mean(diff**2)))

# ---------- Figure 2: vector field quiver comparison ----------
qs_q = np.linspace(-8, 8, 16)
ps_q = np.linspace(-8, 8, 16)
Qq, Pq = np.meshgrid(qs_q, ps_q)

dQ_true = Pq
dP_true = -Vprime(Qq)

qtq = torch.tensor(Qq.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
ptq = torch.tensor(Pq.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
Hq = model(qtq, ptq)
dH_dq = torch.autograd.grad(Hq, qtq, grad_outputs=torch.ones_like(Hq), retain_graph=True)[0]
dH_dp = torch.autograd.grad(Hq, ptq, grad_outputs=torch.ones_like(Hq))[0]
dQ_learned = dH_dp.detach().numpy().reshape(Qq.shape)
dP_learned = -dH_dq.detach().numpy().reshape(Pq.shape)

fig, axes = plt.subplots(1, 2, figsize=(11, 5))
axes[0].quiver(Qq, Pq, dQ_true, dP_true, color='#2255CC', angles='xy')
axes[0].set_title('True vector field $(\\dot q, \\dot p)$')
axes[0].set_xlabel('q'); axes[0].set_ylabel('p')
axes[0].set_xlim(-8,8); axes[0].set_ylim(-8,8)

axes[1].quiver(Qq, Pq, dQ_learned, dP_learned, color='#D62728', angles='xy')
axes[1].set_title('HNN-learned vector field')
axes[1].set_xlabel('q'); axes[1].set_ylabel('p')
axes[1].set_xlim(-8,8); axes[1].set_ylim(-8,8)

plt.tight_layout()
plt.savefig('hnn_vector_field_comparison.png', dpi=150)
plt.close()
print("saved hnn_vector_field_comparison.png")

vf_rmse = np.sqrt(np.mean((dQ_learned-dQ_true)**2 + (dP_learned-dP_true)**2))
print("Vector field RMSE:", vf_rmse)
