import numpy as np
import torch, torch.nn as nn

def V(q): return -0.5*q**2 + (q**4)/100.0
def Hamiltonian(Q, P): return 0.5*P**2 + V(Q)

Q = np.load('Q.npy'); P = np.load('P.npy')
Hgrid = Hamiltonian(Q, P)
dq = 30/127; dp = dq

# exact reference: <H> should be EXACTLY constant (each trajectory conserves H)
fine_times = np.linspace(0, 1, 21)
exact_energy = []
for tv in fine_times:
    ref = np.load(f'rho_ref_t{tv}.npy') if tv in [0.0,0.25,0.5,0.75,1.0] else None
print("Using the 5 saved reference snapshots to confirm exact energy conservation:")
for tv in [0.0,0.25,0.5,0.75,1.0]:
    ref = np.load(f'rho_ref_t{tv}.npy')
    mass = np.sum(ref)*dq*dp
    energy = np.sum(Hgrid*ref)*dq*dp / mass
    print(f"t={tv}: <H> (exact) = {energy:.6f}, mass={mass:.6f}")

# retrain baseline PINN (same config as before) and evaluate <H> over the fine time grid
torch.manual_seed(0)
def Vprime_t(q): return -q + 4*q**3/100.0
q0c, p0c, sigma = 1.0, 0.0, 1.0

class PINN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p, t): return self.net(torch.cat([q,p,t], dim=1))

def sample_collocation(n):
    q=(torch.rand(n,1)*30-15).requires_grad_(True)
    p=(torch.rand(n,1)*30-15).requires_grad_(True)
    t=(torch.rand(n,1)*1.0).requires_grad_(True)
    return q,p,t
def sample_ic(n):
    q=torch.randn(n,1)*3+q0c; p=torch.randn(n,1)*3+p0c; t=torch.zeros(n,1)
    rho0=torch.exp(-((q-q0c)**2+(p-p0c)**2)/(2*sigma**2))/(2*np.pi*sigma**2)
    return q,p,t,rho0

model = PINN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
for epoch in range(1200):
    opt.zero_grad()
    q,p,t = sample_collocation(1500)
    rho = model(q,p,t)
    drho_dt = torch.autograd.grad(rho,t,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dq = torch.autograd.grad(rho,q,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho,p,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
    residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
    loss_pde = torch.mean(residual**2)
    q_ic,p_ic,t_ic,rho0_t = sample_ic(800)
    loss_ic = torch.mean((model(q_ic,p_ic,t_ic)-rho0_t)**2)
    loss = loss_pde + 50*loss_ic
    loss.backward(); opt.step()
print("PINN trained, final loss:", float(loss.item()))

Qt = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1)
Pt = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1)
pinn_energy = []
pinn_mass = []
for tv in fine_times:
    Tt = torch.full_like(Qt, float(tv))
    with torch.no_grad():
        pred = model(Qt, Pt, Tt).numpy().reshape(Q.shape)
    mass = np.sum(pred)*dq*dp
    energy = np.sum(Hgrid*pred)*dq*dp / mass
    pinn_energy.append(energy)
    pinn_mass.append(mass)

exact_energy_const = 0.5*0**2 + V(1.0)  # H(q0,p0) for the point mass of the initial Gaussian center
print("exact H(q0,p0) =", exact_energy_const)

np.save('energy_conservation.npy', np.stack([fine_times, pinn_energy, pinn_mass]))
print("PINN <H> range:", min(pinn_energy), max(pinn_energy))
