"""
Propagate the initial Gaussian density using the LEARNED Hamiltonian's
vector field via the exact method of characteristics (same mathematical
approach as our exact reference, just with a learned right-hand side).

Because any Hamiltonian vector field is exactly divergence-free, mass
conservation here is a property of the METHOD (moving points along a
Hamiltonian flow), not something we had to add via a loss term or a
normalization trick.
"""
import numpy as np
import torch
import torch.nn as nn
import time

q0, p0, sigma = 1.0, 0.0, 1.0

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
    def forward(self, q, p):
        return self.net(torch.cat([q, p], dim=1))

model = HNN(hidden=64)
model.load_state_dict(torch.load('hnn_model.pt'))

def learned_rhs_batch(Q, P):
    """Vectorized RHS using the learned Hamiltonian's gradient, for a whole
    grid of (Q,P) points at once (numpy in, numpy out)."""
    q_t = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    p_t = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    H = model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), retain_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), retain_graph=False)[0]
    qdot = dH_dp.detach().numpy().reshape(Q.shape)
    pdot = -dH_dq.detach().numpy().reshape(P.shape)
    return qdot, pdot

def rk4_step_learned(state, dt):
    Q, P = state
    k1q, k1p = learned_rhs_batch(Q, P)
    k2q, k2p = learned_rhs_batch(Q + 0.5*dt*k1q, P + 0.5*dt*k1p)
    k3q, k3p = learned_rhs_batch(Q + 0.5*dt*k2q, P + 0.5*dt*k2p)
    k4q, k4p = learned_rhs_batch(Q + dt*k3q, P + dt*k3p)
    Qn = Q + (dt/6.0)*(k1q + 2*k2q + 2*k3q + k4q)
    Pn = P + (dt/6.0)*(k1p + 2*k2p + 2*k3p + k4p)
    return Qn, Pn

def integrate_backward_learned(Q, P, t, n_steps=100):
    dt = -t / n_steps
    state = (Q.copy(), P.copy())
    for _ in range(n_steps):
        state = rk4_step_learned(state, dt)
    return state

def initial_gaussian(q, p, q0, p0, sigma):
    return np.exp(-((q-q0)**2 + (p-p0)**2) / (2*sigma**2)) / (2*np.pi*sigma**2)

Q = np.load('Q.npy'); P = np.load('P.npy')
ref = np.load('rho_ref_t1.0.npy')
dq = 30/127

print("Propagating density using the LEARNED Hamiltonian's vector field...")
t_start = time.time()
Q0_learned, P0_learned = integrate_backward_learned(Q, P, t=1.0, n_steps=100)
rho_hnn = initial_gaussian(Q0_learned, P0_learned, q0, p0, sigma)
elapsed = time.time() - t_start
print("propagation time:", elapsed, "s")

mass_hnn = np.sum(rho_hnn)*dq*dq
mse_hnn = np.mean((rho_hnn - ref)**2)
print("HNN-propagated mass (should be ~1 automatically, no normalization applied):", mass_hnn)
print("MSE vs exact reference:", mse_hnn)
print("min density:", rho_hnn.min(), "max density:", rho_hnn.max())

def moments(rho, Q, P, dq, dp):
    mass = np.sum(rho)*dq*dp
    qbar = np.sum(Q*rho)*dq*dp/mass
    pbar = np.sum(P*rho)*dq*dp/mass
    cov_qq = np.sum((Q-qbar)**2*rho)*dq*dp/mass
    cov_pp = np.sum((P-pbar)**2*rho)*dq*dp/mass
    cov_qp = np.sum((Q-qbar)*(P-pbar)*rho)*dq*dp/mass
    return qbar, pbar, cov_qq, cov_pp, cov_qp

qbar_e, pbar_e, cqq_e, cpp_e, cqp_e = moments(ref, Q, P, dq, dq)
qbar_h, pbar_h, cqq_h, cpp_h, cqp_h = moments(rho_hnn, Q, P, dq, dq)
print(f"Exact: mean=({qbar_e:.2f},{pbar_e:.2f}) cov_qq={cqq_e:.3f} cov_pp={cpp_e:.3f} cov_qp={cqp_e:.3f}")
print(f"HNN:   mean=({qbar_h:.2f},{pbar_h:.2f}) cov_qq={cqq_h:.3f} cov_pp={cpp_h:.3f} cov_qp={cqp_h:.3f}")

np.save('rho_hnn_t1.npy', rho_hnn)
