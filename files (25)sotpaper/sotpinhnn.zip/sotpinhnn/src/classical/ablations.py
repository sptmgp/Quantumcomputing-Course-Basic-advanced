import torch, torch.nn as nn, numpy as np, time, json

torch.manual_seed(0)
def Vprime_t(q): return -q + 4*q**3/100.0
q0, p0, sigma = 1.0, 0.0, 1.0

class SineLayer(nn.Module):
    def __init__(self, i,o,w0=1.0):
        super().__init__(); self.lin=nn.Linear(i,o); self.w0=w0
    def forward(self,x): return torch.sin(self.w0*self.lin(x))

class PINN(nn.Module):
    def __init__(self, hidden=48, arch='tanh'):
        super().__init__()
        if arch=='tanh':
            self.net = nn.Sequential(
                nn.Linear(3,hidden), nn.Tanh(),
                nn.Linear(hidden,hidden), nn.Tanh(),
                nn.Linear(hidden,hidden), nn.Tanh(),
                nn.Linear(hidden,1))
        else:  # sine/SIREN
            self.net = nn.Sequential(
                SineLayer(3,hidden,w0=1.0),
                SineLayer(hidden,hidden,w0=1.0),
                SineLayer(hidden,hidden,w0=1.0),
                nn.Linear(hidden,1))
    def forward(self,q,p,t): return self.net(torch.cat([q,p,t],dim=1))

def sample_collocation(n):
    q=(torch.rand(n,1)*30-15).requires_grad_(True)
    p=(torch.rand(n,1)*30-15).requires_grad_(True)
    t=(torch.rand(n,1)*1.0).requires_grad_(True)
    return q,p,t

def sample_ic(n):
    q=torch.randn(n,1)*3+q0; p=torch.randn(n,1)*3+p0; t=torch.zeros(n,1)
    rho0=torch.exp(-((q-q0)**2+(p-p0)**2)/(2*sigma**2))/(2*np.pi*sigma**2)
    return q,p,t,rho0

def train_and_eval(arch='tanh', N_colloc=1000, N_ic=500, lam=50, epochs=700, hidden=48):
    torch.manual_seed(0)
    model = PINN(hidden=hidden, arch=arch)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    t0=time.time()
    for epoch in range(epochs):
        opt.zero_grad()
        q,p,t = sample_collocation(N_colloc)
        rho = model(q,p,t)
        drho_dt = torch.autograd.grad(rho,t,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        drho_dq = torch.autograd.grad(rho,q,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        drho_dp = torch.autograd.grad(rho,p,grad_outputs=torch.ones_like(rho),create_graph=True)[0]
        residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
        loss_pde = torch.mean(residual**2)
        q_ic,p_ic,t_ic,rho0_t = sample_ic(N_ic)
        loss_ic = torch.mean((model(q_ic,p_ic,t_ic)-rho0_t)**2)
        loss = loss_pde + lam*loss_ic
        loss.backward(); opt.step()
    train_time = time.time()-t0

    Q = np.load('Q.npy'); P = np.load('P.npy')
    Qt = torch.tensor(Q.flatten(),dtype=torch.float32).view(-1,1)
    Pt = torch.tensor(P.flatten(),dtype=torch.float32).view(-1,1)
    Tt = torch.ones_like(Qt)
    with torch.no_grad():
        pred = model(Qt,Pt,Tt).numpy().reshape(Q.shape)
    ref = np.load('rho_ref_t1.0.npy')
    dq=(30/127); dp=dq
    mass = float(np.sum(pred)*dq*dp)
    mse = float(np.mean((pred-ref)**2))
    minval = float(pred.min())
    return dict(train_time=train_time, mass=mass, mse=mse, min_density=minval, final_loss=float(loss.item()))

results = {}

print("=== Ablation 1: activation function ===")
for arch in ['tanh','sine']:
    r = train_and_eval(arch=arch)
    print(arch, r)
    results[f'arch_{arch}'] = r

print("=== Ablation 2: collocation point density ===")
for N in [300, 1000, 3000]:
    r = train_and_eval(arch='tanh', N_colloc=N)
    print('N_colloc=',N, r)
    results[f'ncolloc_{N}'] = r

print("=== Ablation 3: IC loss weight lambda ===")
for lam in [5, 50, 500]:
    r = train_and_eval(arch='tanh', lam=lam)
    print('lambda=',lam, r)
    results[f'lambda_{lam}'] = r

with open('ablation_results.json','w') as f:
    json.dump(results, f, indent=2)
print("saved ablation_results.json")
