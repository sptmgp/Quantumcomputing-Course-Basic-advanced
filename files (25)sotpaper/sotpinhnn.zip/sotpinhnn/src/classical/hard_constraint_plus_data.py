"""
Hard-constraint PINN + sparse data supervision (following Zhang et al.
2023's PINN-Vlasov strategy of combining PDE residual with labeled
distribution-function samples, rather than residual-only training).

We can generate labeled data essentially for free, since we have an EXACT
characteristics-based solver (no PIC simulation needed, unlike Zhang et al.,
because this Hamiltonian is non-dissipative). This tests directly whether
sparse ground-truth supervision -- not just a better architecture -- is
what's needed to recover the correct shearing dynamics.
"""
import numpy as np
import torch
import torch.nn as nn
import time
from reference_solution import integrate_backward, initial_gaussian

torch.manual_seed(0)

def Vprime_t(q): return -q + 4*q**3/100.0
q0, p0, sigma = 1.0, 0.0, 1.0
DOMAIN = 15.0

class RawNet(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
            nn.Softplus(),
        )
    def forward(self, x): return self.net(x)

N_GRID = 14
qs_train = torch.linspace(-DOMAIN, DOMAIN, N_GRID)
ps_train = torch.linspace(-DOMAIN, DOMAIN, N_GRID)
Qg_train, Pg_train = torch.meshgrid(qs_train, ps_train, indexing='ij')
Qg_flat = Qg_train.flatten().view(-1, 1)
Pg_flat = Pg_train.flatten().view(-1, 1)
dq_train = (2*DOMAIN) / (N_GRID - 1)
dp_train = dq_train
N_SPATIAL = Qg_flat.shape[0]

def exact_ref_batch(q_np, p_np, t_val):
    """Exact density at a batch of (q,p) points for a single time t_val,
    via backward-characteristics + initial Gaussian (cheap, vectorized)."""
    Q0, P0 = integrate_backward(q_np, p_np, t_val, n_steps=100)
    return initial_gaussian(Q0, P0, q0, p0, sigma)

model = RawNet(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

N_T = 8
N_DATA_PER_T = 150
DATA_DOMAIN = 10.0  # sample data points from a tighter region where mass actually lives
EPOCHS = 800

print("Training hard-constraint + data-supervised PINN...")
t_start = time.time()
for epoch in range(EPOCHS):
    opt.zero_grad()

    t_rand = torch.rand(N_T - 1, 1)
    t_vals = torch.cat([torch.zeros(1,1), t_rand], dim=0)

    # --- PDE residual + Z(t) computation on the fixed grid, as before ---
    q_batch = Qg_flat.repeat(N_T, 1).requires_grad_(True)
    p_batch = Pg_flat.repeat(N_T, 1).requires_grad_(True)
    t_batch = t_vals.repeat_interleave(N_SPATIAL, dim=0).requires_grad_(True)

    raw = model(torch.cat([q_batch, p_batch, t_batch], dim=1))
    raw_grouped = raw.view(N_T, N_SPATIAL)
    Z = raw_grouped.sum(dim=1, keepdim=True) * dq_train * dp_train + 1e-12
    Z_expanded = Z.repeat_interleave(N_SPATIAL, dim=0)
    rho = raw / Z_expanded

    drho_dq = torch.autograd.grad(rho, q_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho, p_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dt = torch.autograd.grad(rho, t_batch, grad_outputs=torch.ones_like(rho), create_graph=True)[0]

    residual = drho_dt + p_batch*drho_dq - Vprime_t(q_batch)*drho_dp
    loss_pde = torch.mean(residual**2)

    rho_t0 = rho[:N_SPATIAL]
    rho0_target = torch.exp(-((Qg_flat-q0)**2 + (Pg_flat-p0)**2)/(2*sigma**2)) / (2*np.pi*sigma**2)
    loss_ic = torch.mean((rho_t0 - rho0_target)**2)

    # --- NEW: sparse data supervision at each of the same N_T times ---
    data_losses = []
    for i in range(N_T):
        t_i = float(t_vals[i, 0].item())
        q_data = (np.random.rand(N_DATA_PER_T)*2-1)*DATA_DOMAIN
        p_data = (np.random.rand(N_DATA_PER_T)*2-1)*DATA_DOMAIN
        exact_vals = exact_ref_batch(q_data, p_data, t_i)  # numpy, no grad needed (target)

        q_data_t = torch.tensor(q_data, dtype=torch.float32).view(-1,1)
        p_data_t = torch.tensor(p_data, dtype=torch.float32).view(-1,1)
        t_data_t = torch.full_like(q_data_t, t_i)
        raw_data = model(torch.cat([q_data_t, p_data_t, t_data_t], dim=1))
        rho_data_pred = raw_data / Z[i].detach()  # normalize using this epoch's Z(t_i) (detached: data loss shouldn't backprop into the Z-defining grid pass twice; residual path already does that)
        exact_t = torch.tensor(exact_vals, dtype=torch.float32).view(-1,1)
        data_losses.append(torch.mean((rho_data_pred - exact_t)**2))

    loss_data = torch.stack(data_losses).mean()

    loss = loss_pde + 50*loss_ic + 200*loss_data
    loss.backward()
    opt.step()

    if epoch % 100 == 0:
        print(epoch, "loss:", float(loss.item()), "pde:", float(loss_pde.item()),
              "ic:", float(loss_ic.item()), "data:", float(loss_data.item()))

train_time = time.time() - t_start
print("Training time:", train_time, "s")
torch.save(model.state_dict(), 'hard_constraint_data_model.pt')
print("saved")
