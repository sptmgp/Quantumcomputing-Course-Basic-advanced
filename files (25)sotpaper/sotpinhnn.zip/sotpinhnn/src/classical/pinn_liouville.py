"""
Attempt: train a PINN to solve the Liouville transport equation
    d(rho)/dt + p * d(rho)/dq - V'(q) * d(rho)/dp = 0
for the quartic double-well Hamiltonian (single period, t in [0,1]),
and check it against the exact characteristics-based reference.

This is a known hard case for PINNs: pure advection/transport PDEs are a
documented PINN failure mode (see Krishnapriyan et al. 2021,
"Characterizing possible failure modes in physics-informed neural
networks" -- they specifically study convection equations as a failure
case). We test honestly rather than assuming either outcome.
"""
import torch, torch.nn as nn, numpy as np, time

torch.manual_seed(0)

def Vprime_t(q):
    return -q + 4*q**3/100.0

q0, p0, sigma = 1.0, 0.0, 1.0

class PINN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
    def forward(self, q, p, t):
        x = torch.cat([q, p, t], dim=1)
        return self.net(x)

model = PINN()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

N_collocation = 1500
N_ic = 800

def sample_collocation(n):
    q = (torch.rand(n,1)*30 - 15).requires_grad_(True)
    p = (torch.rand(n,1)*30 - 15).requires_grad_(True)
    t = (torch.rand(n,1)*1.0).requires_grad_(True)
    return q, p, t

def sample_ic(n):
    # oversample near the initial Gaussian's support so the IC loss is meaningful
    q = (torch.randn(n,1)*3 + q0)
    p = (torch.randn(n,1)*3 + p0)
    t = torch.zeros(n,1)
    rho0 = torch.exp(-((q-q0)**2 + (p-p0)**2)/(2*sigma**2)) / (2*np.pi*sigma**2)
    return q, p, t, rho0

print("Training PINN on Liouville transport equation...")
t_start = time.time()
loss_history = []
for epoch in range(1500):
    optimizer.zero_grad()
    q, p, t = sample_collocation(N_collocation)
    rho = model(q, p, t)
    drho_dt = torch.autograd.grad(rho, t, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dq = torch.autograd.grad(rho, q, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    drho_dp = torch.autograd.grad(rho, p, grad_outputs=torch.ones_like(rho), create_graph=True)[0]
    residual = drho_dt + p*drho_dq - Vprime_t(q)*drho_dp
    loss_pde = torch.mean(residual**2)

    q_ic, p_ic, t_ic, rho0_target = sample_ic(N_ic)
    rho_ic_pred = model(q_ic, p_ic, t_ic)
    loss_ic = torch.mean((rho_ic_pred - rho0_target)**2)

    loss = loss_pde + 50*loss_ic
    loss.backward()
    optimizer.step()
    loss_history.append(float(loss.item()))
    if epoch % 300 == 0:
        print(epoch, "loss:", float(loss.item()), "pde:", float(loss_pde.item()), "ic:", float(loss_ic.item()))

train_time = time.time() - t_start
print("PINN training time:", train_time, "s")

# Evaluate against exact reference at t=1
Q = np.load('Q.npy'); P = np.load('P.npy')
rho_ref = np.load('rho_ref_t1.npy')

Qt = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1)
Pt = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1)
Tt = torch.ones_like(Qt)

with torch.no_grad():
    rho_pred = model(Qt, Pt, Tt).numpy().reshape(Q.shape)

mse = np.mean((rho_pred - rho_ref)**2)
max_abs_ref = np.max(np.abs(rho_ref))
rel_err = np.mean(np.abs(rho_pred - rho_ref)) / (np.mean(np.abs(rho_ref)) + 1e-12)
print("MSE vs exact reference at t=1:", mse)
print("mean relative error:", rel_err)
print("max predicted density:", rho_pred.max(), "max reference density:", rho_ref.max())
print("predicted total mass (should be ~1):", np.sum(rho_pred)*(30/127)*(30/127))

np.save('rho_pred_t1.npy', rho_pred)
np.save('loss_history.npy', np.array(loss_history))
