import numpy as np
import matplotlib.pyplot as plt

Q = np.load('Q_final.npy'); P = np.load('P_final.npy')

fig, axes = plt.subplots(2, 4, figsize=(15, 7))
vmax = max(np.load(f'rho_exact_final_{p}.npy').max() for p in range(1,5))
for i, period in enumerate(range(1,5)):
    ref = np.load(f'rho_exact_final_{period}.npy')
    hnn = np.load(f'rho_hnn_final_{period}.npy')
    axes[0,i].pcolormesh(Q, P, ref, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
    axes[0,i].set_title(f'period {period}')
    axes[1,i].pcolormesh(Q, P, hnn, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
    for ax in [axes[0,i], axes[1,i]]:
        ax.set_xticks([]); ax.set_yticks([])
    if i == 0:
        axes[0,i].set_ylabel('Exact\n(chaotic)')
        axes[1,i].set_ylabel('HNN')
plt.tight_layout()
plt.savefig('chaos_multikick_snapshots.png', dpi=150)
plt.close()

periods = [1,2,3,4]
mse = [5.057e-06, 2.973e-05, 6.248e-05, 7.387e-05]
mse_original_pinn_p1 = 6.1e-5  # original failing configuration, single smooth period, for reference

plt.figure(figsize=(6.5,4.3))
plt.plot(periods, mse, 'o-', color='#4FA85F', label='HNN vs. exact chaotic reference')
plt.axhline(mse_original_pinn_p1, color='#D66B4F', linestyle='--',
            label='Original failing PINN (single smooth period, for reference)')
plt.yscale('log')
plt.xlabel('kick period')
plt.ylabel('MSE vs. exact reference (log scale)')
plt.title('HNN error growth under actual chaotic dynamics\n(delta-kicked double well, matched grid/substeps)')
plt.legend(fontsize=8)
plt.xticks(periods)
plt.tight_layout()
plt.savefig('chaos_error_growth.png', dpi=150)
plt.close()
print("saved both figures")
