"""
STEP 1: Exact reference solution for the full periodically delta-kicked
chaotic double well (the actual system in Gomez et al. Fig. 2 -- not the
single smooth period tested so far in this paper).

One period = kick first, then smooth Hamiltonian flow for time T=1,
following the operator ordering U(T) = U0 * Ukick in the source paper
(Sec. 3): kick shifts p -> p - beta'(q) = p - 0.5 (constant, since
beta(q)=q/2 for this system), then the quartic double-well flow acts.

To build the exact reference at N periods via characteristics, we invert
this map N times starting from every point on our evaluation grid:
  1. invert the flow (integrate Hamilton's equations backward by T=1)
  2. invert the kick (p += 0.5)
repeated N times, then evaluate the known initial Gaussian at the
resulting point. This is exact, using the TRUE dynamics -- our reference
against which both the original PINN and the HNN will be judged.
"""
import numpy as np
import time
from reference_solution import rk4_step, initial_gaussian

KICK_SHIFT = 0.5  # beta'(q) = 0.5, constant, from beta(q) = q/2
T_PERIOD = 1.0
q0, p0, sigma = 1.0, 0.0, 1.0

def invert_one_period(Q, P, n_substeps=60):
    """Undo one period: invert flow (backward RK4 by T_PERIOD), then invert kick."""
    dt = -T_PERIOD / n_substeps
    state = np.array([Q, P])
    for _ in range(n_substeps):
        state = rk4_step(state, dt)
    Q_postkick, P_postkick = state[0], state[1]
    # invert the kick: forward kick was p -> p - 0.5, so invert: p -> p + 0.5
    P_prekick = P_postkick + KICK_SHIFT
    return Q_postkick, P_prekick

def exact_density_after_n_periods(Q, P, n_periods, n_substeps=60):
    Qc, Pc = Q.copy(), P.copy()
    for _ in range(n_periods):
        Qc, Pc = invert_one_period(Qc, Pc, n_substeps)
    return initial_gaussian(Qc, Pc, q0, p0, sigma)

if __name__ == "__main__":
    n = 100  # slightly reduced grid for the multi-period exploratory test
    qs = np.linspace(-15, 15, n)
    ps = np.linspace(-15, 15, n)
    Q, P = np.meshgrid(qs, ps)
    dq = qs[1]-qs[0]; dp = ps[1]-ps[0]

    np.save('Q_mk.npy', Q); np.save('P_mk.npy', P)

    for n_periods in [1, 2, 3, 4, 5]:
        t0 = time.time()
        rho = exact_density_after_n_periods(Q, P, n_periods, n_substeps=60)
        elapsed = time.time() - t0
        mass = np.sum(rho)*dq*dp
        print(f"periods={n_periods}: elapsed={elapsed:.2f}s, mass={mass:.6f}, max_density={rho.max():.4f}")
        np.save(f'rho_exact_mk_{n_periods}.npy', rho)
