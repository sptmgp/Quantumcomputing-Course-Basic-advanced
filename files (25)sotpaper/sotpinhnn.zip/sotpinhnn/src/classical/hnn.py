"""
Hamiltonian Neural Network (HNN), following Greydanus, Dzamba, and
Yosinski (NeurIPS 2019), applied to the same double-well problem.

KEY DIFFERENCE FROM THE PINN APPROACH: instead of training a network to
directly regress the density field rho(q,p,t) against the Liouville PDE
residual, we train a network H_theta(q,p) to match observed equations of
motion (qdot, pdot) via autograd-computed Hamilton's equations:
    qdot_pred = dH_theta/dp,   pdot_pred = -dH_theta/dq

Once trained, we use the LEARNED vector field to propagate the initial
density via the exact method of characteristics (the same mathematically
exact approach used for our reference solution, just with a learned
right-hand side instead of the analytically known one).

WHY THIS MATTERS STRUCTURALLY: any vector field of the Hamiltonian form
(dq/dt, dp/dt) = (dH/dp, -dH/dq) is exactly divergence-free (Liouville's
theorem), regardless of whether H_theta is the TRUE Hamiltonian or only an
approximation. This means mass conservation is a mathematical property of
the METHOD, not something learned or enforced by a loss penalty -- a much
stronger guarantee than the grid-normalization hard constraint used
earlier. The open question is only how accurately H_theta captures the
true dynamics (i.e., shape/shear accuracy), not whether probability leaks.
"""
import numpy as np
import torch
import torch.nn as nn
import time

torch.manual_seed(0)

def V(q): return -0.5*q**2 + (q**4)/100.0
def Vprime_true(q): return -q + 4*q**3/100.0
def true_rhs(q, p):
    return p, -Vprime_true(q)

# ---------- generate training data (sampled trajectory data, as in Greydanus et al.) ----------
N_TRAIN = 2000
DOMAIN = 10.0  # sample where the dynamics is most relevant; HNN training doesn't need the full [-15,15] box
q_train = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
p_train = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
qdot_train, pdot_train = true_rhs(q_train, p_train)

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
    def forward(self, q, p):
        x = torch.cat([q, p], dim=1)
        return self.net(x)

model = HNN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

q_t = torch.tensor(q_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
p_t = torch.tensor(p_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
qdot_t = torch.tensor(qdot_train, dtype=torch.float32).view(-1,1)
pdot_t = torch.tensor(pdot_train, dtype=torch.float32).view(-1,1)

print("Training Hamiltonian Neural Network on trajectory data...")
t_start = time.time()
for epoch in range(2000):
    opt.zero_grad()
    H = model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
    qdot_pred = dH_dp
    pdot_pred = -dH_dq
    loss = torch.mean((qdot_pred - qdot_t)**2) + torch.mean((pdot_pred - pdot_t)**2)
    loss.backward()
    opt.step()
    if epoch % 400 == 0:
        print(epoch, "vector field MSE loss:", float(loss.item()))

train_time = time.time() - t_start
print("HNN training time:", train_time, "s")

torch.save(model.state_dict(), 'hnn_model.pt')
print("saved")

# quick sanity check of learned vector field accuracy on held-out points
q_test = (np.random.rand(500)*2-1)*DOMAIN
p_test = (np.random.rand(500)*2-1)*DOMAIN
qdot_true_test, pdot_true_test = true_rhs(q_test, p_test)
q_test_t = torch.tensor(q_test, dtype=torch.float32).view(-1,1).requires_grad_(True)
p_test_t = torch.tensor(p_test, dtype=torch.float32).view(-1,1).requires_grad_(True)
H_test = model(q_test_t, p_test_t)
dH_dq_test = torch.autograd.grad(H_test, q_test_t, grad_outputs=torch.ones_like(H_test), create_graph=True)[0]
dH_dp_test = torch.autograd.grad(H_test, p_test_t, grad_outputs=torch.ones_like(H_test), create_graph=True)[0]
qdot_pred_test = dH_dp_test.detach().numpy().flatten()
pdot_pred_test = -dH_dq_test.detach().numpy().flatten()
vf_mse = np.mean((qdot_pred_test-qdot_true_test)**2 + (pdot_pred_test-pdot_true_test)**2)
print("Held-out vector-field MSE:", vf_mse)
