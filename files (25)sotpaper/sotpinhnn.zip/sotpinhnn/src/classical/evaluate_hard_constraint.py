import numpy as np
import torch
import torch.nn as nn

DOMAIN = 15.0

class RawNet(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
            nn.Softplus(),
        )
    def forward(self, x): return self.net(x)

model = RawNet(hidden=64)
model.load_state_dict(torch.load('hard_constraint_model.pt'))
model.eval()

def normalized_eval(q_np, p_np, t_val, grid_n):
    """Evaluate normalized density at query points (q_np,p_np) at time t_val,
    using a grid of size grid_n x grid_n for the normalization integral --
    lets us test with a DIFFERENT (finer) grid than was used in training."""
    qs = np.linspace(-DOMAIN, DOMAIN, grid_n)
    ps = np.linspace(-DOMAIN, DOMAIN, grid_n)
    Qg, Pg = np.meshgrid(qs, ps, indexing='ij')
    dq = (2*DOMAIN)/(grid_n-1); dp = dq

    with torch.no_grad():
        qg_t = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
        pg_t = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
        tg_t = torch.full_like(qg_t, t_val)
        raw_grid = model(torch.cat([qg_t,pg_t,tg_t], dim=1))
        Z = raw_grid.sum() * dq * dp

        q_t = torch.tensor(q_np.flatten(), dtype=torch.float32).view(-1,1)
        p_t = torch.tensor(p_np.flatten(), dtype=torch.float32).view(-1,1)
        t_t = torch.full_like(q_t, t_val)
        raw_q = model(torch.cat([q_t,p_t,t_t], dim=1))
        rho = (raw_q / Z).numpy().reshape(q_np.shape)
    return rho, float(Z.item())

# Load the SAME 128x128 reference grid used for the original classical baseline
Q = np.load('Q.npy'); P = np.load('P.npy')
ref_t1 = np.load('rho_ref_t1.0.npy')
dq_fine = 30/127; dp_fine = dq_fine

print("=== Test 1: mass conservation on the TRAINING grid resolution (14x14) ===")
pred_14, Z14 = normalized_eval(Q, P, 1.0, grid_n=14)
mass_14 = np.sum(pred_14)*dq_fine*dp_fine
print("mass (evaluated on fine grid, normalized using coarse 14x14 Z):", mass_14)

print("=== Test 2: mass conservation using a genuinely FINER normalization grid (128x128) ===")
pred_128, Z128 = normalized_eval(Q, P, 1.0, grid_n=128)
mass_128 = np.sum(pred_128)*dq_fine*dp_fine
print("mass (normalized using fine 128x128 Z):", mass_128)

print("=== Test 3: pointwise accuracy vs exact reference (same metric as classical baseline) ===")
mse_14 = np.mean((pred_14-ref_t1)**2)
mse_128 = np.mean((pred_128-ref_t1)**2)
print("MSE (14x14 norm):", mse_14)
print("MSE (128x128 norm):", mse_128)
print("max density (pred):", pred_128.max(), "max density (exact):", ref_t1.max())
print("min density (pred):", pred_128.min(), "  <- should be >=0 (Softplus guarantees positivity)")

np.save('hc_pred_t1_fine.npy', pred_128)
