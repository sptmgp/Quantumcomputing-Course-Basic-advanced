"""
STEP 2: Same multi-kick chaotic map, but using the LEARNED Hamiltonian's
vector field (from Sec. VIII's HNN) for the flow segments between kicks.
The kick itself is applied exactly (it's already known in closed form --
no learning needed for it).
"""
import numpy as np
import torch
import torch.nn as nn
import time

KICK_SHIFT = 0.5
T_PERIOD = 1.0
q0, p0, sigma = 1.0, 0.0, 1.0

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
    def forward(self, q, p):
        return self.net(torch.cat([q, p], dim=1))

model = HNN(hidden=64)
model.load_state_dict(torch.load('hnn_model.pt'))

def learned_rhs_batch(Q, P):
    q_t = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    p_t = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    H = model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), retain_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), retain_graph=False)[0]
    qdot = dH_dp.detach().numpy().reshape(Q.shape)
    pdot = -dH_dq.detach().numpy().reshape(P.shape)
    return qdot, pdot

def rk4_step_learned(state, dt):
    Q, P = state
    k1q, k1p = learned_rhs_batch(Q, P)
    k2q, k2p = learned_rhs_batch(Q + 0.5*dt*k1q, P + 0.5*dt*k1p)
    k3q, k3p = learned_rhs_batch(Q + 0.5*dt*k2q, P + 0.5*dt*k2p)
    k4q, k4p = learned_rhs_batch(Q + dt*k3q, P + dt*k3p)
    Qn = Q + (dt/6.0)*(k1q + 2*k2q + 2*k3q + k4q)
    Pn = P + (dt/6.0)*(k1p + 2*k2p + 2*k3p + k4p)
    return Qn, Pn

def invert_one_period_learned(Q, P, n_substeps=40):
    dt = -T_PERIOD / n_substeps
    state = (Q.copy(), P.copy())
    for _ in range(n_substeps):
        state = rk4_step_learned(state, dt)
    Q_postkick, P_postkick = state
    P_prekick = P_postkick + KICK_SHIFT
    return Q_postkick, P_prekick

def initial_gaussian(q, p, q0, p0, sigma):
    return np.exp(-((q-q0)**2 + (p-p0)**2) / (2*sigma**2)) / (2*np.pi*sigma**2)

if __name__ == "__main__":
    n = 100
    qs = np.linspace(-15, 15, n)
    ps = np.linspace(-15, 15, n)
    Q, P = np.meshgrid(qs, ps)
    dq = qs[1]-qs[0]; dp = ps[1]-ps[0]

    Qc, Pc = Q.copy(), P.copy()
    for n_periods in [1, 2, 3]:
        t0 = time.time()
        Qc, Pc = invert_one_period_learned(Qc, Pc, n_substeps=40)
        rho = initial_gaussian(Qc, Pc, q0, p0, sigma)
        elapsed = time.time() - t0
        mass = np.sum(rho)*dq*dp
        print(f"periods={n_periods}: elapsed={elapsed:.2f}s, mass={mass:.6f}, max_density={rho.max():.4f}")
        np.save(f'rho_hnn_mk_{n_periods}.npy', rho)
    np.save('Q_mk100.npy', Q); np.save('P_mk100.npy', P)
