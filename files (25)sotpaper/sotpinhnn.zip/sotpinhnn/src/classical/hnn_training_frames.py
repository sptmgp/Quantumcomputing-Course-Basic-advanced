"""
Train the Hamiltonian Neural Network, saving the propagated density at
t=1 every N epochs, to animate it converging toward the correct
conserved, sheared shape.
"""
import numpy as np
import torch
import torch.nn as nn
from reference_solution import initial_gaussian

torch.manual_seed(0)
np.random.seed(0)

def Vprime_true(q): return -q + 4*q**3/100.0
def true_rhs(q, p): return p, -Vprime_true(q)
q0c, p0c, sigma = 1.0, 0.0, 1.0

N_TRAIN = 2000
DOMAIN = 10.0
q_train = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
p_train = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
qdot_train, pdot_train = true_rhs(q_train, p_train)

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

model = HNN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

q_t = torch.tensor(q_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
p_t = torch.tensor(p_train, dtype=torch.float32).view(-1,1).requires_grad_(True)
qdot_t = torch.tensor(qdot_train, dtype=torch.float32).view(-1,1)
pdot_t = torch.tensor(pdot_train, dtype=torch.float32).view(-1,1)

# small grid for cheap per-checkpoint characteristics propagation
n_grid = 50
qs = np.linspace(-15,15,n_grid); ps = np.linspace(-15,15,n_grid)
Qg, Pg = np.meshgrid(qs,ps)
dq = qs[1]-qs[0]

def learned_rhs_batch(model, Q, P):
    qt = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    pt = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    H = model(qt, pt)
    dH_dq = torch.autograd.grad(H, qt, grad_outputs=torch.ones_like(H), retain_graph=True)[0]
    dH_dp = torch.autograd.grad(H, pt, grad_outputs=torch.ones_like(H), retain_graph=False)[0]
    return dH_dp.detach().numpy().reshape(Q.shape), -dH_dq.detach().numpy().reshape(P.shape)

def propagate(model, n_substeps=25):
    dt = -1.0/n_substeps
    Q,P = Qg.copy(), Pg.copy()
    for _ in range(n_substeps):
        k1q,k1p = learned_rhs_batch(model,Q,P)
        k2q,k2p = learned_rhs_batch(model,Q+0.5*dt*k1q,P+0.5*dt*k1p)
        k3q,k3p = learned_rhs_batch(model,Q+0.5*dt*k2q,P+0.5*dt*k2p)
        k4q,k4p = learned_rhs_batch(model,Q+dt*k3q,P+dt*k3p)
        Q = Q+(dt/6)*(k1q+2*k2q+2*k3q+k4q)
        P = P+(dt/6)*(k1p+2*k2p+2*k3p+k4p)
    return initial_gaussian(Q, P, q0c, p0c, sigma)

frames = []
masses = []
epochs_saved = []
N_EPOCHS = 1600
SAVE_EVERY = 200

for epoch in range(N_EPOCHS+1):
    opt.zero_grad()
    H = model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), create_graph=True)[0]
    loss = torch.mean((dH_dp-qdot_t)**2) + torch.mean((-dH_dq-pdot_t)**2)
    loss.backward()
    opt.step()

    if epoch % SAVE_EVERY == 0:
        rho = propagate(model)
        mass = np.sum(rho)*dq*dq
        frames.append(rho.copy())
        masses.append(mass)
        epochs_saved.append(epoch)
        print(f"epoch {epoch}: loss={float(loss.item()):.3f}, mass={mass:.5f}")

np.savez('hnn_training_frames.npz', frames=np.array(frames), masses=np.array(masses),
          epochs=np.array(epochs_saved), Q=Qg, P=Pg)
print("saved", len(frames), "frames")
