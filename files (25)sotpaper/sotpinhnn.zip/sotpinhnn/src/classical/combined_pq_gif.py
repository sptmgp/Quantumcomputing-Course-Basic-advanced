"""
Combined animated phase-space comparison: exact trajectory, HNN-learned
trajectory, and PINN's density-peak "trajectory", all moving together on
one plot over t=0 to 1.
"""
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
import io
from reference_solution import rk4_step, Vprime

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

hnn_model = HNN(hidden=64)
hnn_model.load_state_dict(torch.load('/home/claude/chaos_pinn/hnn/hnn_model.pt'))

def learned_rhs(q, p):
    qt = torch.tensor([[q]], dtype=torch.float32, requires_grad=True)
    pt = torch.tensor([[p]], dtype=torch.float32, requires_grad=True)
    H = hnn_model(qt, pt)
    dH_dq = torch.autograd.grad(H, qt, grad_outputs=torch.ones_like(H), retain_graph=True)[0].item()
    dH_dp = torch.autograd.grad(H, pt, grad_outputs=torch.ones_like(H))[0].item()
    return np.array([dH_dp, -dH_dq])

def rk4_step_learned(state, dt):
    k1 = learned_rhs(*state)
    k2 = learned_rhs(*(state + 0.5*dt*k1))
    k3 = learned_rhs(*(state + 0.5*dt*k2))
    k4 = learned_rhs(*(state + dt*k3))
    return state + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)

# load precomputed PINN peak trajectory
pinn_times = np.linspace(0,1,25)
pinn_peaks = np.array([
    (0.76,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),
    (1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),
    (1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),
    (1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15),(1.06,0.15)])

n_frames = 40
t_max = 1.0
dt = t_max/n_frames
times = np.linspace(0, t_max, n_frames+1)

exact_state = np.array([1.0, 0.0])
hnn_state = np.array([1.0, 0.0])
exact_hist = [exact_state.copy()]
hnn_hist = [hnn_state.copy()]
for _ in range(n_frames):
    exact_state = rk4_step(exact_state, dt)
    hnn_state = rk4_step_learned(hnn_state, dt)
    exact_hist.append(exact_state.copy())
    hnn_hist.append(hnn_state.copy())
exact_hist = np.array(exact_hist)
hnn_hist = np.array(hnn_hist)

# background streamlines
qs_bg = np.linspace(-3, 3, 20)
ps_bg = np.linspace(-3, 3, 20)
Qg, Pg = np.meshgrid(qs_bg, ps_bg)
dQ = Pg
dP = -Vprime(Qg)

images = []
for frame in range(n_frames+1):
    t_now = times[frame]
    fig, ax = plt.subplots(figsize=(6.5,6))
    ax.streamplot(Qg, Pg, dQ, dP, color='lightgray', density=0.8, linewidth=0.5, arrowsize=0.6)

    ax.plot(exact_hist[:frame+1,0], exact_hist[:frame+1,1], color='#2255CC', linewidth=2, label='Exact')
    ax.plot(hnn_hist[:frame+1,0], hnn_hist[:frame+1,1], color='#D62728', linewidth=2, linestyle='--', label='HNN-learned')

    pinn_idx = np.searchsorted(pinn_times, t_now)
    pinn_idx = min(pinn_idx, len(pinn_peaks)-1)
    ax.plot(pinn_peaks[:pinn_idx+1,0], pinn_peaks[:pinn_idx+1,1], color='#F2A93B', linewidth=2, marker='s', markersize=4, label='PINN density peak')

    ax.scatter(exact_hist[frame,0], exact_hist[frame,1], color='#2255CC', s=80, zorder=5)
    ax.scatter(hnn_hist[frame,0], hnn_hist[frame,1], color='#D62728', s=80, zorder=5, marker='^')
    ax.scatter(pinn_peaks[pinn_idx,0], pinn_peaks[pinn_idx,1], color='#F2A93B', s=80, zorder=5, marker='s')

    ax.scatter([1.0],[0.0], color='black', s=50, marker='*', zorder=6)
    ax.set_xlim(-3,3); ax.set_ylim(-3,3)
    ax.set_xlabel('q'); ax.set_ylabel('p')
    ax.set_title(f'Phase space: exact vs. HNN vs. PINN density peak\nt = {t_now:.2f}')
    ax.legend(loc='lower left', fontsize=9)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=95)
    plt.close(fig)
    buf.seek(0)
    images.append(Image.open(buf).convert('RGB'))

durations = [90]*len(images)
durations[-1] = 2500
images[0].save('combined_pq_comparison.gif', save_all=True, append_images=images[1:],
                duration=durations, loop=0)
print("saved combined_pq_comparison.gif,", len(images), "frames")
