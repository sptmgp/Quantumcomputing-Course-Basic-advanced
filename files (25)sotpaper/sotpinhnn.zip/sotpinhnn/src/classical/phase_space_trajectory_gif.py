"""
Animated phase-space trajectories: a ring of particles moving through the
double-well potential under (a) the exact Hamiltonian flow and (b) the
HNN-learned flow, overlaid on the streamline background -- an animated
version of the static propagator_comparison.png figure.
"""
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
import io

def V(q): return -0.5*q**2 + (q**4)/100.0
def Vprime(q): return -q + 4*q**3/100.0

def hamilton_rhs(state):
    q, p = state
    return np.array([p, -Vprime(q)])

def rk4_step(state, dt):
    k1 = hamilton_rhs(state)
    k2 = hamilton_rhs(state + 0.5*dt*k1)
    k3 = hamilton_rhs(state + 0.5*dt*k2)
    k4 = hamilton_rhs(state + dt*k3)
    return state + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)

class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

model = HNN(hidden=64)
model.load_state_dict(torch.load('/home/claude/chaos_pinn/hnn/hnn_model.pt'))

def learned_rhs(q, p):
    qt = torch.tensor([[q]], dtype=torch.float32, requires_grad=True)
    pt = torch.tensor([[p]], dtype=torch.float32, requires_grad=True)
    H = model(qt, pt)
    dH_dq = torch.autograd.grad(H, qt, grad_outputs=torch.ones_like(H), retain_graph=True)[0].item()
    dH_dp = torch.autograd.grad(H, pt, grad_outputs=torch.ones_like(H))[0].item()
    return np.array([dH_dp, -dH_dq])

def rk4_step_learned(state, dt):
    k1 = learned_rhs(*state)
    k2 = learned_rhs(*(state + 0.5*dt*k1))
    k3 = learned_rhs(*(state + 0.5*dt*k2))
    k4 = learned_rhs(*(state + dt*k3))
    return state + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)

# background streamlines (static, computed once)
qs_bg = np.linspace(-8, 8, 25)
ps_bg = np.linspace(-8, 8, 25)
Qg, Pg = np.meshgrid(qs_bg, ps_bg)
dQ = Pg
dP = -Vprime(Qg)
speed = np.sqrt(dQ**2 + dP**2)

# initial ring of particles
n_particles = 14
angles = np.linspace(0, 2*np.pi, n_particles, endpoint=False)
q0s = 1.0 + 1.0*np.cos(angles)
p0s = 0.0 + 1.0*np.sin(angles)

n_frames = 40
t_max = 1.0
dt = t_max/n_frames

exact_states = [np.array([q0s[i], p0s[i]]) for i in range(n_particles)]
hnn_states = [np.array([q0s[i], p0s[i]]) for i in range(n_particles)]
exact_history = [np.array(exact_states)]
hnn_history = [np.array(hnn_states)]

for frame in range(n_frames):
    exact_states = [rk4_step(s, dt) for s in exact_states]
    hnn_states = [rk4_step_learned(s, dt) for s in hnn_states]
    exact_history.append(np.array(exact_states))
    hnn_history.append(np.array(hnn_states))

print("integration done, building frames...")

images = []
cmap = plt.cm.plasma
for frame in range(n_frames+1):
    fig, ax = plt.subplots(figsize=(6.5,6))
    ax.streamplot(Qg, Pg, dQ, dP, color=speed, cmap='Greys', density=1.0, linewidth=0.5, arrowsize=0.7)

    exact_pts = exact_history[frame]
    hnn_pts = hnn_history[frame]
    # trails: draw last few positions with fading alpha
    trail_len = 8
    for i in range(n_particles):
        start = max(0, frame-trail_len)
        exact_trail = np.array([exact_history[k][i] for k in range(start, frame+1)])
        hnn_trail = np.array([hnn_history[k][i] for k in range(start, frame+1)])
        ax.plot(exact_trail[:,0], exact_trail[:,1], color='#2255CC', alpha=0.5, linewidth=1.2)
        ax.plot(hnn_trail[:,0], hnn_trail[:,1], color='#D62728', alpha=0.5, linewidth=1.2, linestyle='--')

    ax.scatter(exact_pts[:,0], exact_pts[:,1], color='#2255CC', s=35, zorder=5, label='Exact (SOT-equivalent)')
    ax.scatter(hnn_pts[:,0], hnn_pts[:,1], color='#D62728', s=35, zorder=5, marker='^', label='HNN-learned')

    ax.set_xlim(-8,8); ax.set_ylim(-8,8)
    ax.set_xlabel('q'); ax.set_ylabel('p')
    ax.set_title(f'Phase-space trajectories: exact vs. HNN-learned dynamics\nt = {frame*dt:.2f}')
    ax.legend(loc='upper right', fontsize=9)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=95)
    plt.close(fig)
    buf.seek(0)
    images.append(Image.open(buf).convert('RGB'))

durations = [80]*len(images)
durations[-1] = 2000
images[0].save('phase_space_trajectories.gif', save_all=True, append_images=images[1:],
                duration=durations, loop=0)
print("saved phase_space_trajectories.gif,", len(images), "frames")
