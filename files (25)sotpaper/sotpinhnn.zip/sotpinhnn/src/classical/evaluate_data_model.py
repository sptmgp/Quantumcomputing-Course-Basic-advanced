import numpy as np
import torch
import torch.nn as nn

DOMAIN = 15.0

class RawNet(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
            nn.Softplus(),
        )
    def forward(self, x): return self.net(x)

model = RawNet(hidden=64)
model.load_state_dict(torch.load('hard_constraint_data_model.pt'))
model.eval()

def normalized_eval(q_np, p_np, t_val, grid_n):
    qs = np.linspace(-DOMAIN, DOMAIN, grid_n)
    ps = np.linspace(-DOMAIN, DOMAIN, grid_n)
    Qg, Pg = np.meshgrid(qs, ps, indexing='ij')
    dq = (2*DOMAIN)/(grid_n-1); dp = dq
    with torch.no_grad():
        qg_t = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
        pg_t = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
        tg_t = torch.full_like(qg_t, t_val)
        raw_grid = model(torch.cat([qg_t,pg_t,tg_t], dim=1))
        Z = raw_grid.sum() * dq * dp
        q_t = torch.tensor(q_np.flatten(), dtype=torch.float32).view(-1,1)
        p_t = torch.tensor(p_np.flatten(), dtype=torch.float32).view(-1,1)
        t_t = torch.full_like(q_t, t_val)
        raw_q = model(torch.cat([q_t,p_t,t_t], dim=1))
        rho = (raw_q / Z).numpy().reshape(q_np.shape)
    return rho, float(Z.item())

Q = np.load('Q.npy'); P = np.load('P.npy')
ref_t1 = np.load('rho_ref_t1.0.npy')
dq_fine = 30/127

pred_128, Z128 = normalized_eval(Q, P, 1.0, grid_n=128)
mass_128 = np.sum(pred_128)*dq_fine*dq_fine
mse_128 = np.mean((pred_128-ref_t1)**2)
print("mass (fine grid):", mass_128)
print("MSE vs exact:", mse_128)
print("min density:", pred_128.min())

def moments(rho, Q, P, dq, dp):
    mass = np.sum(rho)*dq*dp
    qbar = np.sum(Q*rho)*dq*dp/mass
    pbar = np.sum(P*rho)*dq*dp/mass
    cov_qq = np.sum((Q-qbar)**2*rho)*dq*dp/mass
    cov_pp = np.sum((P-pbar)**2*rho)*dq*dp/mass
    cov_qp = np.sum((Q-qbar)*(P-pbar)*rho)*dq*dp/mass
    return qbar, pbar, cov_qq, cov_pp, cov_qp

qbar_e, pbar_e, cqq_e, cpp_e, cqp_e = moments(ref_t1, Q, P, dq_fine, dq_fine)
qbar_p, pbar_p, cqq_p, cpp_p, cqp_p = moments(pred_128, Q, P, dq_fine, dq_fine)
print(f"Exact:  mean=({qbar_e:.2f},{pbar_e:.2f}) cov_qq={cqq_e:.3f} cov_pp={cpp_e:.3f} cov_qp={cqp_e:.3f}")
print(f"PINN:   mean=({qbar_p:.2f},{pbar_p:.2f}) cov_qq={cqq_p:.3f} cov_pp={cpp_p:.3f} cov_qp={cqp_p:.3f}")

np.save('hcd_pred_t1_fine.npy', pred_128)
