"""
Direct before/after: mass conservation vs time, original failing PINN vs
both fixes, on the SAME 21-point time grid used in the original Fig. 4,
so the comparison is exact and immediate.
"""
import numpy as np
import torch
import torch.nn as nn
from reference_solution import rk4_step, initial_gaussian

DOMAIN = 15.0
q0, p0, sigma = 1.0, 0.0, 1.0
fine_times = np.linspace(0, 1, 21)

# ============ Original failing PINN mass (already computed, reuse values) ============
original_mass = np.array([3.65531707,3.64998746,3.64486527,3.63988137,3.6349659,
                           3.63004947,3.62506533,3.619946,3.61462474,3.60903907,
                           3.60312629,3.59682727,3.59008622,3.58284831,3.5750618,
                           3.56668186,3.55766153,3.54796195,3.53754497,3.52637863,3.51443172])

# ============ Hard-constraint + data (stabilized) mass vs time ============
class HCNet(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(3, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
            nn.Softplus())
    def forward(self, x): return self.net(x)

hc_model = HCNet(hidden=64)
hc_model.load_state_dict(torch.load('hard_constraint_data_model_v2.pt'))
hc_model.eval()

def hc_mass_at(t_val, grid_n=128):
    qs = np.linspace(-DOMAIN, DOMAIN, grid_n)
    ps = np.linspace(-DOMAIN, DOMAIN, grid_n)
    Qg, Pg = np.meshgrid(qs, ps, indexing='ij')
    dq = (2*DOMAIN)/(grid_n-1); dp = dq
    with torch.no_grad():
        qt = torch.tensor(Qg.flatten(), dtype=torch.float32).view(-1,1)
        pt = torch.tensor(Pg.flatten(), dtype=torch.float32).view(-1,1)
        tt = torch.full_like(qt, t_val)
        raw = hc_model(torch.cat([qt,pt,tt], dim=1))
        Z = float((raw.sum()*dq*dp).item())   # Z = integral of raw over the grid
        rho = raw / Z                          # normalized density
        mass = float((rho.sum()*dq*dp).item()) # should be exactly 1 by construction
    return mass

print("Computing hard-constraint mass vs time...")
hc_mass = np.array([hc_mass_at(t) for t in fine_times])
print(hc_mass)

# ============ HNN mass vs time (via characteristics propagation) ============
class HNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, q, p): return self.net(torch.cat([q, p], dim=1))

hnn_model = HNN(hidden=64)
hnn_model.load_state_dict(torch.load('hnn_model.pt'))

def learned_rhs_batch(Q, P):
    q_t = torch.tensor(Q.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    p_t = torch.tensor(P.flatten(), dtype=torch.float32).view(-1,1).requires_grad_(True)
    H = hnn_model(q_t, p_t)
    dH_dq = torch.autograd.grad(H, q_t, grad_outputs=torch.ones_like(H), retain_graph=True)[0]
    dH_dp = torch.autograd.grad(H, p_t, grad_outputs=torch.ones_like(H), retain_graph=False)[0]
    return dH_dp.detach().numpy().reshape(Q.shape), -dH_dq.detach().numpy().reshape(P.shape)

def rk4_step_learned(state, dt):
    Q, P = state
    k1q,k1p = learned_rhs_batch(Q,P)
    k2q,k2p = learned_rhs_batch(Q+0.5*dt*k1q,P+0.5*dt*k1p)
    k3q,k3p = learned_rhs_batch(Q+0.5*dt*k2q,P+0.5*dt*k2p)
    k4q,k4p = learned_rhs_batch(Q+dt*k3q,P+dt*k3p)
    Qn = Q+(dt/6)*(k1q+2*k2q+2*k3q+k4q)
    Pn = P+(dt/6)*(k1p+2*k2p+2*k3p+k4p)
    return (Qn,Pn)

def hnn_mass_at(t_val, grid_n=90, n_substeps=40):
    qs = np.linspace(-DOMAIN, DOMAIN, grid_n)
    ps = np.linspace(-DOMAIN, DOMAIN, grid_n)
    Qg, Pg = np.meshgrid(qs, ps)
    dq = qs[1]-qs[0]; dp = ps[1]-ps[0]
    if t_val == 0:
        rho = initial_gaussian(Qg, Pg, q0, p0, sigma)
        return float(np.sum(rho)*dq*dp)
    dt = -t_val/n_substeps
    state = (Qg.copy(), Pg.copy())
    for _ in range(n_substeps):
        state = rk4_step_learned(state, dt)
    rho = initial_gaussian(state[0], state[1], q0, p0, sigma)
    return float(np.sum(rho)*dq*dp)

print("Computing HNN mass vs time (subset of time points for speed)...")
hnn_times_subset = fine_times[::4]  # every 4th point: t=0,0.2,0.4,0.6,0.8,1.0 approx
hnn_mass_subset = np.array([hnn_mass_at(t) for t in hnn_times_subset])
print(hnn_times_subset)
print(hnn_mass_subset)

np.savez('mass_vs_time_all.npz', fine_times=fine_times, original_mass=original_mass,
         hc_mass=hc_mass, hnn_times=hnn_times_subset, hnn_mass=hnn_mass_subset)
