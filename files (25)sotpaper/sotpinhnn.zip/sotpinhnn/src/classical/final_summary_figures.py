import numpy as np
import matplotlib.pyplot as plt

# Fig: training stability comparison (v1 unstable vs v2 stabilized), using the
# actual logged values printed during training (every 100 epochs, real data)
epochs_v1 = [0,100,200,300,400,500,600,700]
loss_v1   = [0.0477,0.02635,0.00234,0.04751,0.03655,0.04320,0.05383,0.04312]
epochs_v2 = [0,100,200,300,400,500,600,700,800,900]
loss_v2   = [0.01676,0.01466,0.00231,0.00177,0.00101,0.000335,0.02455,0.01940,0.01177,0.02225]
best_v2 = 0.000315

plt.figure(figsize=(7,4.5))
plt.plot(epochs_v1, loss_v1, 'o-', color='#D66B4F', label='v1: fixed LR, no clipping, final checkpoint (unstable)')
plt.plot(epochs_v2, loss_v2, 'o-', color='#4FA8D8', label='v2: LR schedule + grad clipping + best checkpoint')
plt.axhline(best_v2, color='#4FA8D8', linestyle=':', linewidth=1, label=f'v2 best loss used for evaluation ({best_v2:.1e})')
plt.yscale('log')
plt.xlabel('epoch')
plt.ylabel('total training loss (log scale)')
plt.title('Training stability: data-supervised hard-constraint PINN\n(values logged every 100 epochs during actual training runs)')
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig('fig_training_stability.png', dpi=150)
plt.close()

# Fig: summary bar chart across all four tested configurations
labels = ['Soft constraint\n(original)', 'Hard constraint\nonly', 'Hard constraint\n+ data (unstable)', 'Hard constraint\n+ data (stabilized)']
mse_vals = [6.10e-5, 9.15e-5, 9.12e-5, 7.77e-6]
colors = ['#D66B4F', '#E8B84F', '#B0B0B0', '#4FA85F']

plt.figure(figsize=(7.5,4.5))
bars = plt.bar(labels, mse_vals, color=colors)
plt.yscale('log')
plt.ylabel('MSE vs. exact reference at t=1 (log scale)')
plt.title('Summary: pointwise accuracy across all four tested configurations')
for bar, val in zip(bars, mse_vals):
    plt.text(bar.get_x()+bar.get_width()/2, val*1.3, f'{val:.2e}', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig('fig_summary_all_methods.png', dpi=150)
plt.close()
print("saved both figures")
