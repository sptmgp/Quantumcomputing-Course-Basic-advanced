import numpy as np
import matplotlib.pyplot as plt

Q = np.load('Q.npy'); P = np.load('P.npy')
ref = np.load('rho_ref_t1.0.npy')
pred_soft = np.load('../pinn_vs_exact_t1.npy') if False else None
pred_hc = np.load('hc_pred_t1_fine.npy')
pred_hcd = np.load('hcd_v2_pred_t1_fine.npy')

fig, axes = plt.subplots(1, 3, figsize=(15,4.3))
vmax = max(ref.max(), pred_hcd.max())

im0 = axes[0].pcolormesh(Q, P, ref, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
axes[0].set_title('Exact reference')
axes[0].set_xlabel('q'); axes[0].set_ylabel('p')
plt.colorbar(im0, ax=axes[0])

im1 = axes[1].pcolormesh(Q, P, pred_hc, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
axes[1].set_title('Hard-constraint only\n(mass=1, but wrong shear)')
axes[1].set_xlabel('q'); axes[1].set_ylabel('p')
plt.colorbar(im1, ax=axes[1])

im2 = axes[2].pcolormesh(Q, P, pred_hcd, shading='auto', cmap='viridis', vmin=0, vmax=vmax)
axes[2].set_title('Hard-constraint + data supervision\n(mass=1, correct shear direction)')
axes[2].set_xlabel('q'); axes[2].set_ylabel('p')
plt.colorbar(im2, ax=axes[2])

plt.tight_layout()
plt.savefig('final_three_way_comparison.png', dpi=150)
print("saved")
