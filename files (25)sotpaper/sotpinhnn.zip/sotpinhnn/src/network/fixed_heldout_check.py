import numpy as np
import torch
import torch.nn as nn
from coupled_system import true_rhs

class NetworkHNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, x): return self.net(x)

model = NetworkHNN(hidden=64)
model.load_state_dict(torch.load('network_hnn.pt'))

np.random.seed(999)  # different seed from training, genuine held-out
DOMAIN = 4.5
N = 1000
qA2,pA2,qB2,pB2 = [(np.random.rand(N)*2-1)*DOMAIN for _ in range(4)]
qAd,pAd,qBd,pBd = true_rhs(qA2,pA2,qB2,pB2)

qA2_t = torch.tensor(qA2,dtype=torch.float32).view(-1,1).requires_grad_(True)
pA2_t = torch.tensor(pA2,dtype=torch.float32).view(-1,1).requires_grad_(True)
qB2_t = torch.tensor(qB2,dtype=torch.float32).view(-1,1).requires_grad_(True)
pB2_t = torch.tensor(pB2,dtype=torch.float32).view(-1,1).requires_grad_(True)

H2 = model(torch.cat([qA2_t,pA2_t,qB2_t,pB2_t],dim=1))
g2 = torch.autograd.grad(H2, [qA2_t,pA2_t,qB2_t,pB2_t], grad_outputs=torch.ones_like(H2))
dH_dqA, dH_dpA, dH_dqB, dH_dpB = [g.detach().numpy().flatten() for g in g2]

# CORRECT Hamilton's equations mapping this time
qAdot_pred, pAdot_pred = dH_dpA, -dH_dqA
qBdot_pred, pBdot_pred = dH_dpB, -dH_dqB

mse_qA = np.mean((qAdot_pred-qAd)**2)
mse_pA = np.mean((pAdot_pred-pAd)**2)
mse_qB = np.mean((qBdot_pred-qBd)**2)
mse_pB = np.mean((pBdot_pred-pBd)**2)
total_mse = np.mean([mse_qA,mse_pA,mse_qB,mse_pB])

print("Corrected held-out vector-field MSE (per component):")
print(f"  qAdot: {mse_qA:.4f}   pAdot: {mse_pA:.4f}")
print(f"  qBdot: {mse_qB:.4f}   pBdot: {mse_pB:.4f}")
print(f"  total: {total_mse:.4f}")
print(f"typical |pAdot| scale in this domain: {np.abs(pAd).mean():.2f} (mean abs value)")
