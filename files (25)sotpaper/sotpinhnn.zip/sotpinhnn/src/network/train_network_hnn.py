"""
Train a Hamiltonian Neural Network on the 4D coupled-oscillator network,
following exactly the same method validated on the single-particle case
(train on local equations-of-motion data, no density-field regression).
"""
import numpy as np
import torch
import torch.nn as nn
import time
from coupled_system import true_rhs, LAMBDA

torch.manual_seed(0)
np.random.seed(0)

N_TRAIN = 3000
DOMAIN = 4.5
qA = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
pA = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
qB = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
pB = (np.random.rand(N_TRAIN)*2-1)*DOMAIN
qAdot, pAdot, qBdot, pBdot = true_rhs(qA, pA, qB, pB)

class NetworkHNN(nn.Module):
    """H_theta(qA,pA,qB,pB) -- one scalar generating function for the
    WHOLE network, not one per node -- this is what makes the coupling
    (the network structure) something the model can represent at all."""
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, x):
        return self.net(x)

model = NetworkHNN(hidden=64)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

qA_t = torch.tensor(qA, dtype=torch.float32).view(-1,1).requires_grad_(True)
pA_t = torch.tensor(pA, dtype=torch.float32).view(-1,1).requires_grad_(True)
qB_t = torch.tensor(qB, dtype=torch.float32).view(-1,1).requires_grad_(True)
pB_t = torch.tensor(pB, dtype=torch.float32).view(-1,1).requires_grad_(True)
qAdot_t = torch.tensor(qAdot, dtype=torch.float32).view(-1,1)
pAdot_t = torch.tensor(pAdot, dtype=torch.float32).view(-1,1)
qBdot_t = torch.tensor(qBdot, dtype=torch.float32).view(-1,1)
pBdot_t = torch.tensor(pBdot, dtype=torch.float32).view(-1,1)

print("Training network-wide HNN on 4D coupled system...")
t0 = time.time()
for epoch in range(2500):
    opt.zero_grad()
    x = torch.cat([qA_t,pA_t,qB_t,pB_t], dim=1)
    H = model(x)
    grads = torch.autograd.grad(H, [qA_t,pA_t,qB_t,pB_t], grad_outputs=torch.ones_like(H), create_graph=True)
    dH_dqA, dH_dpA, dH_dqB, dH_dpB = grads
    qAdot_pred, pAdot_pred = dH_dpA, -dH_dqA
    qBdot_pred, pBdot_pred = dH_dpB, -dH_dqB
    loss = (torch.mean((qAdot_pred-qAdot_t)**2) + torch.mean((pAdot_pred-pAdot_t)**2)
            + torch.mean((qBdot_pred-qBdot_t)**2) + torch.mean((pBdot_pred-pBdot_t)**2))
    loss.backward()
    opt.step()
    if epoch % 500 == 0:
        print(epoch, "loss:", float(loss.item()))

print("training time:", time.time()-t0, "s")
torch.save(model.state_dict(), 'network_hnn.pt')

# held-out check
q_test = (np.random.rand(1000)*2-1)*DOMAIN
qA2,pA2,qB2,pB2 = [(np.random.rand(1000)*2-1)*DOMAIN for _ in range(4)]
qAd,pAd,qBd,pBd = true_rhs(qA2,pA2,qB2,pB2)
qA2_t = torch.tensor(qA2,dtype=torch.float32).view(-1,1).requires_grad_(True)
pA2_t = torch.tensor(pA2,dtype=torch.float32).view(-1,1).requires_grad_(True)
qB2_t = torch.tensor(qB2,dtype=torch.float32).view(-1,1).requires_grad_(True)
pB2_t = torch.tensor(pB2,dtype=torch.float32).view(-1,1).requires_grad_(True)
H2 = model(torch.cat([qA2_t,pA2_t,qB2_t,pB2_t],dim=1))
g2 = torch.autograd.grad(H2, [qA2_t,pA2_t,qB2_t,pB2_t], grad_outputs=torch.ones_like(H2))
pred = [g2[1].detach().numpy().flatten()*-1, g2[0].detach().numpy().flatten(),
        g2[3].detach().numpy().flatten()*-1, g2[2].detach().numpy().flatten()]
true_vals = [pAd, qAd, pBd, qBd]
vf_mse = np.mean([(p-t)**2 for p,t in zip(pred,true_vals)])
print("held-out vector-field MSE:", vf_mse)
