import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from coupled_system import integrate_forward, true_rhs

class NetworkHNN(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
    def forward(self, x): return self.net(x)

model = NetworkHNN(hidden=64)
model.load_state_dict(torch.load('network_hnn.pt'))

def learned_rhs(qA,pA,qB,pB):
    q = torch.tensor([[qA,pA,qB,pB]], dtype=torch.float32, requires_grad=True)
    H = model(q)
    g = torch.autograd.grad(H, q, grad_outputs=torch.ones_like(H))[0][0]
    dH_dqA,dH_dpA,dH_dqB,dH_dpB = g[0].item(),g[1].item(),g[2].item(),g[3].item()
    return dH_dpA, -dH_dqA, dH_dpB, -dH_dqB

def rk4_step_learned(state, dt):
    qA,pA,qB,pB = state
    k1 = learned_rhs(qA,pA,qB,pB)
    k2 = learned_rhs(qA+0.5*dt*k1[0],pA+0.5*dt*k1[1],qB+0.5*dt*k1[2],pB+0.5*dt*k1[3])
    k3 = learned_rhs(qA+0.5*dt*k2[0],pA+0.5*dt*k2[1],qB+0.5*dt*k2[2],pB+0.5*dt*k2[3])
    k4 = learned_rhs(qA+dt*k3[0],pA+dt*k3[1],qB+dt*k3[2],pB+dt*k3[3])
    qAn = qA+(dt/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0])
    pAn = pA+(dt/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1])
    qBn = qB+(dt/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2])
    pBn = pB+(dt/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3])
    return (qAn,pAn,qBn,pBn)

x0 = (2.0, 0.0, 2.0, 0.0)  # within the well-trained domain
t_max = 2*np.pi
n_steps = 300
exact_traj = integrate_forward(x0, t_max, n_steps)

dt = t_max/n_steps
state = x0
learned_traj = [state]
for _ in range(n_steps):
    state = rk4_step_learned(state, dt)
    learned_traj.append(state)
learned_traj = np.array(learned_traj)

t = np.linspace(0, t_max, n_steps+1)
fig, axes = plt.subplots(1,2, figsize=(11,4.2))
axes[0].plot(t, exact_traj[:,0], color='#2255CC', label='Exact qA(t)')
axes[0].plot(t, learned_traj[:,0], color='#D62728', linestyle='--', label='Learned qA(t)')
axes[0].set_xlabel('t'); axes[0].set_ylabel('qA'); axes[0].legend(); axes[0].set_title('Node A position')

axes[1].plot(exact_traj[:,0], exact_traj[:,2], color='#2255CC', label='Exact')
axes[1].plot(learned_traj[:,0], learned_traj[:,2], color='#D62728', linestyle='--', label='Learned')
axes[1].set_xlabel('qA'); axes[1].set_ylabel('qB'); axes[1].legend(); axes[1].set_title('Coupled trajectory (qA vs qB)')
plt.tight_layout()
plt.savefig('network_trajectory_comparison.png', dpi=150)
print("saved")
final_err = np.sqrt(np.mean((exact_traj[-1]-learned_traj[-1])**2))
print("final-time position error:", final_err)
