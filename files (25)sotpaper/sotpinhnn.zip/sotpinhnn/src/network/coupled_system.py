"""
PIAD-RMI interpretation: Physics-Informed Adaptive Dynamics for a
(small) Perturbed Complex Network -- extending the validated Hamiltonian
Neural Network approach from one isolated oscillator to a NETWORK of
coupled nodes.

Base system: two coupled harmonic oscillators (nodes A, B), following
Gomez et al. 2014 Sec. 6 exactly:
    H = H_A + H_B + H_I
    H_A = pA^2/2 + qA^2/2,  H_B = pB^2/2 + qB^2/2
    H_I = lambda * qA^2 * qB^2 / 2      (the "network edge" / perturbation)

This is a genuine 4D phase space (qA,pA,qB,pB) -- the first real test in
this whole project of whether the HNN approach survives a dimensionality
increase, which every section of the paper so far has flagged as the
necessary next step but never tested.
"""
import numpy as np

LAMBDA = 0.5  # coupling strength, matching the source paper's example

def true_rhs(qA, pA, qB, pB):
    """Exact equations of motion for the coupled 2-oscillator network."""
    qAdot = pA
    pAdot = -qA - LAMBDA*qA*qB**2
    qBdot = pB
    pBdot = -qB - LAMBDA*qA**2*qB
    return qAdot, pAdot, qBdot, pBdot

def rk4_step(state, dt):
    qA,pA,qB,pB = state
    def f(qA,pA,qB,pB):
        return true_rhs(qA,pA,qB,pB)
    k1 = f(qA,pA,qB,pB)
    k2 = f(qA+0.5*dt*k1[0], pA+0.5*dt*k1[1], qB+0.5*dt*k1[2], pB+0.5*dt*k1[3])
    k3 = f(qA+0.5*dt*k2[0], pA+0.5*dt*k2[1], qB+0.5*dt*k2[2], pB+0.5*dt*k2[3])
    k4 = f(qA+dt*k3[0], pA+dt*k3[1], qB+dt*k3[2], pB+dt*k3[3])
    qAn = qA + (dt/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0])
    pAn = pA + (dt/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1])
    qBn = qB + (dt/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2])
    pBn = pB + (dt/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3])
    return (qAn,pAn,qBn,pBn)

def integrate_forward(state0, t_max, n_steps):
    dt = t_max/n_steps
    state = state0
    traj = [state]
    for _ in range(n_steps):
        state = rk4_step(state, dt)
        traj.append(state)
    return np.array(traj)  # (n_steps+1, 4)

if __name__ == "__main__":
    # sanity check: reproduce the qualitative behavior claimed in the
    # source paper (revival collapse due to coupling)
    x0 = (4.0, 0.0, 4.0, 0.0)  # matches Gomez et al.'s example centroid
    traj = integrate_forward(x0, t_max=4*np.pi, n_steps=2000)
    print("trajectory shape:", traj.shape)
    print("qA range:", traj[:,0].min(), traj[:,0].max())
    print("qB range:", traj[:,2].min(), traj[:,2].max())
