"""
Continuous parameter sweep: vary the qubit's dissipation rate gamma and
measure trace-conservation error, mirroring the "sweep a physical noise
parameter, plot performance" style of real quantum-hardware noise studies.
"""
import numpy as np
import torch
import torch.nn as nn
import time

omega = 2*np.pi
T = 1.0
rho00_0, rho11_0, u0, v0 = 0.5, 0.5, 0.5, 0.0

class QPINN(nn.Module):
    def __init__(self, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(1,hidden), nn.Tanh(),
            nn.Linear(hidden,hidden), nn.Tanh(),
            nn.Linear(hidden,hidden), nn.Tanh(),
            nn.Linear(hidden,4))
    def forward(self, t): return self.net(t)

def exact_solution(t, gamma):
    rho11 = rho11_0*np.exp(-gamma*t)
    rho00 = 1 - rho11
    decay = np.exp(-gamma*t/2)
    u = decay*(u0*np.cos(omega*t) + v0*np.sin(omega*t))
    v = decay*(-u0*np.sin(omega*t) + v0*np.cos(omega*t))
    return rho00, rho11, u, v

def train_and_eval(gamma, seed=0, epochs=2500):
    torch.manual_seed(seed)
    model = QPINN()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    t_train = torch.linspace(0,T,300).view(-1,1).requires_grad_(True)
    t0 = torch.zeros(1,1, requires_grad=True)
    for epoch in range(epochs):
        opt.zero_grad()
        out = model(t_train)
        rho00, rho11, uu, vv = out[:,0:1], out[:,1:2], out[:,2:3], out[:,3:4]
        d_rho00 = torch.autograd.grad(rho00, t_train, grad_outputs=torch.ones_like(rho00), create_graph=True)[0]
        d_rho11 = torch.autograd.grad(rho11, t_train, grad_outputs=torch.ones_like(rho11), create_graph=True)[0]
        d_u = torch.autograd.grad(uu, t_train, grad_outputs=torch.ones_like(uu), create_graph=True)[0]
        d_v = torch.autograd.grad(vv, t_train, grad_outputs=torch.ones_like(vv), create_graph=True)[0]
        res00 = d_rho00 - gamma*rho11
        res11 = d_rho11 + gamma*rho11
        resu = d_u - (-(gamma/2)*uu + omega*vv)
        resv = d_v - (-omega*uu - (gamma/2)*vv)
        loss_pde = torch.mean(res00**2+res11**2+resu**2+resv**2)
        out0 = model(t0)
        loss_ic = (out0[:,0]-rho00_0)**2+(out0[:,1]-rho11_0)**2+(out0[:,2]-u0)**2+(out0[:,3]-v0)**2
        loss = loss_pde + 200*loss_ic.squeeze()
        loss.backward()
        opt.step()

    t_test = torch.linspace(0,T,300).view(-1,1)
    with torch.no_grad():
        out = model(t_test).numpy()
    trace_pinn = out[:,0]+out[:,1]
    max_dev = np.max(np.abs(trace_pinn-1))
    return max_dev, float(loss.item())

GAMMAS = [0.05, 0.15, 0.3, 0.5, 0.8, 1.2, 2.0]
results = []
for gamma in GAMMAS:
    t0 = time.time()
    max_dev, final_loss = train_and_eval(gamma)
    print(f"gamma={gamma}: max trace deviation={max_dev:.5f}, final_loss={final_loss:.2e}, time={time.time()-t0:.1f}s")
    results.append(max_dev)

np.save('gamma_sweep_results.npy', np.array([GAMMAS, results]))
