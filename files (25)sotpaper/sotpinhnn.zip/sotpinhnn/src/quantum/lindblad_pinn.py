"""
Quantum generalization test: the classical Liouville operator's quantum
analog is the Lindblad superoperator, governing open quantum systems
(the core object of quantum thermodynamics -- dissipation, relaxation,
decoherence). We test a qubit under amplitude damping + coherent
precession:

    drho/dt = -i[H,rho] + gamma*(sigma_- rho sigma_+ - 1/2{sigma_+ sigma_-, rho})

H = (omega/2) sigma_z. This has a closed-form solution, and -- like the
classical Liouville operator -- it conserves trace(rho) exactly (the
quantum analog of total probability) by construction, independent of any
approximation. We train a PINN on the 4 real ODEs for (rho00, rho11,
Re rho01, Im rho01) WITHOUT hard-coding trace=1, and check whether the
learned solution conserves it, exactly paralleling the classical
mass-conservation test.
"""
import numpy as np
import torch, torch.nn as nn
import matplotlib.pyplot as plt

omega = 2*np.pi
gamma = 0.3
T = 1.0

# initial state |+><+| = 0.5*[[1,1],[1,1]]
rho00_0, rho11_0, u0, v0 = 0.5, 0.5, 0.5, 0.0

def exact_solution(t):
    rho11 = rho11_0*np.exp(-gamma*t)
    rho00 = 1 - rho11
    decay = np.exp(-gamma*t/2)
    u = decay*(u0*np.cos(omega*t) + v0*np.sin(omega*t))
    v = decay*(-u0*np.sin(omega*t) + v0*np.cos(omega*t))
    return rho00, rho11, u, v

t_check = np.linspace(0,T,200)
r00,r11,u,v = exact_solution(t_check)
print("exact trace range:", (r00+r11).min(), (r00+r11).max())

# ---------- PINN ----------
torch.manual_seed(0)
class QPINN(nn.Module):
    def __init__(self, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(1,hidden), nn.Tanh(),
            nn.Linear(hidden,hidden), nn.Tanh(),
            nn.Linear(hidden,hidden), nn.Tanh(),
            nn.Linear(hidden,4))  # rho00, rho11, u, v
    def forward(self, t):
        return self.net(t)

model = QPINN()
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
t_train = torch.linspace(0,T,300).view(-1,1).requires_grad_(True)
t0 = torch.zeros(1,1, requires_grad=True)

for epoch in range(3000):
    opt.zero_grad()
    out = model(t_train)
    rho00, rho11, uu, vv = out[:,0:1], out[:,1:2], out[:,2:3], out[:,3:4]

    d_rho00 = torch.autograd.grad(rho00, t_train, grad_outputs=torch.ones_like(rho00), create_graph=True)[0]
    d_rho11 = torch.autograd.grad(rho11, t_train, grad_outputs=torch.ones_like(rho11), create_graph=True)[0]
    d_u = torch.autograd.grad(uu, t_train, grad_outputs=torch.ones_like(uu), create_graph=True)[0]
    d_v = torch.autograd.grad(vv, t_train, grad_outputs=torch.ones_like(vv), create_graph=True)[0]

    res00 = d_rho00 - gamma*rho11
    res11 = d_rho11 + gamma*rho11
    resu = d_u - (-(gamma/2)*uu + omega*vv)
    resv = d_v - (-omega*uu - (gamma/2)*vv)
    loss_pde = torch.mean(res00**2 + res11**2 + resu**2 + resv**2)

    out0 = model(t0)
    loss_ic = (out0[:,0]-rho00_0)**2 + (out0[:,1]-rho11_0)**2 + (out0[:,2]-u0)**2 + (out0[:,3]-v0)**2
    loss = loss_pde + 200*loss_ic.squeeze()
    loss.backward()
    opt.step()
    if epoch % 1000 == 0:
        print(epoch, float(loss.item()))

t_test = torch.linspace(0,T,300).view(-1,1)
with torch.no_grad():
    out = model(t_test).numpy()
r00p, r11p, up, vp = out[:,0], out[:,1], out[:,2], out[:,3]
trace_pinn = r00p + r11p
t_np = t_test.numpy().flatten()

r00e, r11e, ue, ve = exact_solution(t_np)
mse_pop = np.mean((r11p-r11e)**2)
mse_coh = np.mean((up-ue)**2 + (vp-ve)**2)
print("MSE population:", mse_pop, "MSE coherence:", mse_coh)
print("PINN trace range:", trace_pinn.min(), trace_pinn.max())

np.savez('lindblad_results.npz', t=t_np, r00p=r00p, r11p=r11p, up=up, vp=vp,
         r00e=r00e, r11e=r11e, ue=ue, ve=ve, trace_pinn=trace_pinn)
